/*
 * Copyright (C) 2006 Martin Kaltenbrunner
 * <mkalten@iua.upf.es>
 * GUI for controlling Pure Data (Pd) on the iPod

 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdlib.h>
#include <stdio.h> 
#include <string.h> 
#include <signal.h> 
#include <time.h>
//#include <float.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>
#include "pz.h"
#include "mlist.h"
#include <dirent.h>

// microwindows objects
static GR_WINDOW_ID pdpod_wid;
static GR_GC_ID pdpod_gc;
static GR_WINDOW_ID status_wid;
static GR_WINDOW_ID pause_image;
static GR_WINDOW_ID status_image;
static GR_WINDOW_ID pdpod_buffer;
static GR_WINDOW_INFO wi;
static	GR_EVENT break_event;
static GR_TIMER_ID cpu_timer_id, pd_timer_id;
static menu_st *patch_menu = NULL;
static GR_EVENT break_event;

#define PD_BANG 0
#define PD_VSLIDER 1
#define PD_HSLIDER 2
#define PD_VRADIO 3
#define PD_HRADIO 4
#define PD_NUMBER 5
#define PD_SYMBOL 6
#define PD_TEXT 7

typedef struct widget
{
	int type;
	char name[128];
	int x,y,w,h;
	int min,max;
	float value;
} WIDGET;
static WIDGET *pd_widget[128];
static int widget_count;

// function declarations
void new_pdpod_window(void);
static void check_event();
static int handle_event(GR_EVENT *event);
static void draw_header();
static void draw_status();
static void draw_gui();
static void draw_about_gui();
static void pdpod_quit();
static void update_standard_gui();
static void update_custom_gui();
extern void new_stringview_window(char *buf, char *title);

static void create_status();
static void create_menu();
static void init_values();
static void free_memory();

static void load_patch();
static void parse_patch();
static void start_pd();
static void connect_pd();
static void pause_pd();
static void stop_pd();
static void disconnect_pd();
static int send_message(char *message);
static void read_messages();
static void process_message();

// various variables
static char pd_patch[128];
static const char pd_command[64];
static char patch_directory[64];
static int screen_width,screen_height;
static float screen_multiplier;
static int scroll_value, last_scroll, scroll_diff;
static char loaded,running,connected,paused,about,shift;
static char action_button,forward_button,rewind_button,play_button,menu_button;
static pid_t pd_pid;
static int sockfd_out,sockfd_in;
static int patch_id;
static int menu_entries;
static char directory_entries[128][64];
static int last_cpu;

// creates a new window
void new_pdpod_window(void)
{
	// get the graphics context
	pdpod_gc = pz_get_gc(1);
		
	// create the main window
	pdpod_wid = pz_new_window (0, 21,
				screen_info.cols, screen_info.rows - (HEADER_TOPLINE+1),
				draw_header, handle_event);
	
	 // get screen info
	GrGetWindowInfo(pdpod_wid, &wi);
	
	// select the event types
	GrSelectEvents (pdpod_wid, GR_EVENT_MASK_EXPOSURE | GR_EVENT_MASK_KEY_DOWN | GR_EVENT_MASK_KEY_UP | GR_EVENT_MASK_TIMER);
		

	// create the timer for the busy status animation
	cpu_timer_id = GrCreateTimer (pdpod_wid, 1000);

	// display the window
	GrMapWindow (pdpod_wid);


	// start main app
	draw_header();
	init_values();
	create_status();
	create_menu();
	draw_gui();
}
	
// draw the title bar.
static void draw_header()
{
	pz_draw_header ("PdPod");
}

// reset the variables to their initial values
static void init_values() {
	
	screen_width=screen_info.cols;
	screen_height=screen_info.rows - (HEADER_TOPLINE + 1);
	screen_multiplier = screen_width/160.0f;
	//printf("%d %d\n",screen_width,screen_height);

	// offscreen buffer
	pdpod_buffer = GrNewPixmap(screen_width, screen_height,  NULL);

	widget_count=0;
	patch_id=0;
	
	paused=running=connected=loaded=about=0;
	shift=action_button=forward_button=rewind_button=play_button=menu_button=0;
	scroll_value=last_scroll=scroll_diff=0;
}

static void free_memory() {
	int i;
	for (i=0;i<widget_count;i++) free(pd_widget[i]);

}

// create the circular status animation
static void create_status() {

	// create & show the status window
	status_wid = pz_new_window (4, 4, 12, 12, draw_status, handle_event);
	GrMapWindow (status_wid);

	// create the pixmaps
	pause_image = GrNewPixmap(12, 12,  NULL);
	status_image = GrNewPixmap(12, 12,  NULL);
	GrSetGCForeground(pdpod_gc, WHITE);
	GrFillRect(pause_image,pdpod_gc,0,0,12,12);	
	GrFillRect(status_image,pdpod_gc,0,0,12,12);	
	
	// draw the pause symbol
	GrSetGCForeground(pdpod_gc, GRAY);
	GrFillRect(pause_image,pdpod_gc,0,0,4,12);
	GrFillRect(pause_image,pdpod_gc,8,0,12,12);	
}

// draw the status window contents
static void draw_status() {

	char cpu_load;

	if (paused) {
		GrCopyArea(status_wid, pdpod_gc, 0, 0,  12, 12,pause_image, 0, 0, MWROP_SRCCOPY);
	} else if (running) {

		FILE *stat;
		long system, user, nice, cpu;

		if ((stat = fopen("/proc/stat", "r")) == NULL) {
			GrSetGCForeground(pdpod_gc, WHITE);
			GrFillRect(status_wid,pdpod_gc,0,0,12,12);
			return;	
		}
		
		fscanf(stat, "cpu %ld %ld %ld", &system, &user, &nice);
		fclose(stat);

		cpu = system+user+nice;
		cpu_load = (char)(((cpu-last_cpu)*1.2)/10);
		last_cpu = cpu;

		GrSetGCForeground(pdpod_gc, BLACK);
		GrFillRect(status_image,pdpod_gc,0,0,12,12);	
		GrSetGCForeground(pdpod_gc, WHITE);
		GrFillRect(status_image,pdpod_gc,0, 0,12,12-cpu_load);
		
		GrCopyArea(status_wid, pdpod_gc, 0, 0,  12, 12,status_image, 0, 0, MWROP_SRCCOPY);
	} else {
		GrSetGCForeground(pdpod_gc, WHITE);
		GrFillRect(status_wid,pdpod_gc,0,0,12,12);	
	}
}


// draw the standard gui buffer
static void draw_gui() {

	if (!loaded) {
		if(about) {
			pz_draw_header("about PdPod ...");
			draw_about_gui();
		} else {
			draw_header();
			menu_select_item(patch_menu, patch_id);
			menu_draw(patch_menu);
		}
	} else {	
		if (widget_count>0) update_custom_gui();
		else update_standard_gui();

		GrCopyArea(pdpod_wid, pdpod_gc, 0, 0,
		screen_width, screen_height,
		pdpod_buffer, 0, 0, MWROP_SRCCOPY);
		check_event();
	}
	
}

static void draw_about_gui() {
	int x=3;
	GrSetGCForeground(pdpod_gc, WHITE);
	GrFillRect(pdpod_buffer,pdpod_gc,0,0,screen_width, screen_height);
	GrSetGCForeground(pdpod_gc, BLACK);
	GrText(pdpod_buffer,pdpod_gc,x, 20,"(c) 2006 by Martin Kaltenbrunner",-1,GR_TFASCII);
	GrText(pdpod_buffer,pdpod_gc,x, 35,"Universitat Pompeu Fabra",-1,GR_TFASCII);
	GrText(pdpod_buffer,pdpod_gc,x, 50,"<mkalten@iua.upf.es>",-1,GR_TFASCII);
	GrText(pdpod_buffer,pdpod_gc,x, 75,"PDa iPod port: Guenter Geiger",-1,GR_TFASCII);
	GrText(pdpod_buffer,pdpod_gc,x, 90,"Pure Data (pd): Miller Puckette",-1,GR_TFASCII);
	GrCopyArea(pdpod_wid, pdpod_gc, 0, 0, screen_width, screen_height, pdpod_buffer, 0, 0, MWROP_SRCCOPY);
}

static void update_standard_gui() {

	char value[5];

	GrSetGCForeground(pdpod_gc, WHITE);
	GrFillRect(pdpod_buffer,pdpod_gc,0,0,screen_width, screen_height);
	GrSetGCForeground(pdpod_gc, BLACK);
	GrFillEllipse(pdpod_buffer,pdpod_gc,screen_width/2, screen_height/2,2*screen_height/5, 2*screen_height/5);

	if (menu_button) {
		GrSetGCForeground(pdpod_gc, GRAY);
		GrFillEllipse(pdpod_buffer,pdpod_gc,screen_width/2, screen_height/4,screen_height/8, screen_height/8);
	}

	if (rewind_button) {
		GrSetGCForeground(pdpod_gc, GRAY);
		GrFillEllipse(pdpod_buffer,pdpod_gc,screen_width/3, screen_height/2,screen_height/8, screen_height/8);
	}

	if (forward_button) {
		GrSetGCForeground(pdpod_gc, GRAY);
		GrFillEllipse(pdpod_buffer,pdpod_gc,2*screen_width/3+1, screen_height/2,screen_height/8, screen_height/8);
	}

	if (play_button) {
		GrSetGCForeground(pdpod_gc, GRAY);
		GrFillEllipse(pdpod_buffer,pdpod_gc,screen_width/2, 3*screen_height/4,screen_height/8, screen_height/8);
	}

	if (action_button) GrSetGCForeground(pdpod_gc, GRAY);
	else GrSetGCForeground(pdpod_gc, LTGRAY);
	GrFillEllipse(pdpod_buffer,pdpod_gc,screen_width/2, screen_height/2,screen_height/8, screen_height/8);

	sprintf(value,"%d",scroll_value);
	GrSetGCForeground(pdpod_gc, BLACK);
	GrText(pdpod_buffer,pdpod_gc,screen_width/2-2.5*strlen(value), screen_height/2+5,value,-1,GR_TFASCII);
}

static void update_custom_gui() {
	int i, j,v;
	char value[128];

	GrSetGCForeground(pdpod_gc, WHITE);
	GrFillRect(pdpod_buffer,pdpod_gc,0,0,screen_width, screen_height);

	GrSetGCForeground(pdpod_gc, BLACK);
	for (i=0;i<widget_count;i++) {
		switch(pd_widget[i]->type) {
			case PD_BANG:
				GrRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y,pd_widget[i]->w, pd_widget[i]->h);
				if(pd_widget[i]->value==1) {
					GrFillEllipse(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w/2,pd_widget[i]->y+pd_widget[i]->w/2,pd_widget[i]->w/2-1, pd_widget[i]->h/2-1);
					pd_widget[i]->value=0;
				} else
					GrEllipse(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w/2,pd_widget[i]->y+pd_widget[i]->w/2,pd_widget[i]->w/2-1, pd_widget[i]->h/2-1);
				break;
			case PD_VSLIDER:
				GrRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y,pd_widget[i]->w, pd_widget[i]->h);
				v=((float)pd_widget[i]->h/(pd_widget[i]->max-pd_widget[i]->min))*(pd_widget[i]->max-pd_widget[i]->value);
				GrFillRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y+v,pd_widget[i]->w,2);
				break;
			case PD_HSLIDER:
				GrRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y,pd_widget[i]->w, pd_widget[i]->h);
				v=((float)pd_widget[i]->w/(pd_widget[i]->max-pd_widget[i]->min))*(pd_widget[i]->max-pd_widget[i]->value);
				GrFillRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w-v,pd_widget[i]->y,2,pd_widget[i]->h);
				break;
			case PD_HRADIO:
				for (j=0;j<(pd_widget[i]->w/pd_widget[i]->h);j++) {
					
					GrRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->h*j,pd_widget[i]->y,pd_widget[i]->h,pd_widget[i]->h);

					if (pd_widget[i]->value==j)
						GrFillRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->h*j+2,pd_widget[i]->y+2,pd_widget[i]->h-4,pd_widget[i]->h-4);
				}	
				break;
			case PD_VRADIO:
				for (j=0;j<(pd_widget[i]->h/pd_widget[i]->w);j++) {					
					GrRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y+pd_widget[i]->w*j,pd_widget[i]->w,pd_widget[i]->w);

					if (pd_widget[i]->value==j)
						GrFillRect(pdpod_buffer,pdpod_gc,pd_widget[i]->x+2,pd_widget[i]->y+pd_widget[i]->w*j+2,pd_widget[i]->w-4,pd_widget[i]->w-4);
				}
				break;
			case PD_NUMBER:
				GrLine(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y,pd_widget[i]->x+pd_widget[i]->w-5*screen_multiplier,pd_widget[i]->y);
				GrLine(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w-5*screen_multiplier,pd_widget[i]->y,pd_widget[i]->x+pd_widget[i]->w,pd_widget[i]->y+5*screen_multiplier);
				GrLine(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w,pd_widget[i]->y+5*screen_multiplier,pd_widget[i]->x+pd_widget[i]->w,pd_widget[i]->y+pd_widget[i]->h);
				GrLine(pdpod_buffer,pdpod_gc,pd_widget[i]->x+pd_widget[i]->w,pd_widget[i]->y+pd_widget[i]->h,pd_widget[i]->x,pd_widget[i]->y+pd_widget[i]->h);
				GrLine(pdpod_buffer,pdpod_gc,pd_widget[i]->x,pd_widget[i]->y+pd_widget[i]->h,pd_widget[i]->x,pd_widget[i]->y);
				sprintf(value,"%.1f",pd_widget[i]->value);
				GrText(pdpod_buffer,pdpod_gc,pd_widget[i]->x+2, pd_widget[i]->y+12,value,-1,GR_TFASCII);
				break;
			case PD_TEXT:
				GrText(pdpod_buffer,pdpod_gc,pd_widget[i]->x+2, pd_widget[i]->y+12,pd_widget[i]->name,-1,GR_TFASCII);
				break;
		}
	}
}

/* the directory to scan */
static void create_menu()
{
	DIR *dir;
	struct dirent *subdir;
	int size;

	patch_menu = menu_init(pdpod_wid, "", 0, 1, screen_width, screen_height, NULL, NULL, ASCII);
	menu_entries = 0;

	if (access ("/PureData", F_OK )==0) sprintf(patch_directory,"/PureData");
	else if (access ("/mnt/PureData", F_OK )==0) sprintf(patch_directory,"/mnt/PureData");
	else if (access ("/hp/PureData", F_OK )==0) sprintf(patch_directory,"/hp/PureData");
	else {
		pz_error("patch directory not found");
		return;
	}

	sprintf(pd_command,"%s/lib/pd",patch_directory);

	dir = opendir(patch_directory);
	while ((subdir = readdir(dir))) {
		if(strncmp(subdir->d_name, ".", strlen(subdir->d_name)) == 0) continue;
		if(strncmp(subdir->d_name, "..", strlen(subdir->d_name)) == 0) continue;
		if (strstr(subdir->d_name,".pd")==NULL) continue;

		if(menu_entries > 127) {
			pz_error("too many files");
			break;
		}

		size = strlen(subdir->d_name);
		size = (size > 62 ? 62 : size);

		strncpy(directory_entries[menu_entries], subdir->d_name, size);
		directory_entries[menu_entries][size] = '\0';
		
		menu_add_item(patch_menu, directory_entries[menu_entries], NULL, 0, EXECUTE_MENU);
		menu_entries++;
	}

	menu_entries--;
	closedir(dir);
}

// load the pd patch
static void load_patch()
{
	sprintf(pd_patch,"%s/%s",patch_directory,directory_entries[patch_id]);
	// printf("parsing patch: %s\n",pd_patch);
	parse_patch();

	pz_draw_header(directory_entries[patch_id]);
	draw_gui();

	// printf("loading patch: %s\n",pd_patch);
	start_pd();

	//printf("running: %d\n",running);
	connect_pd();
	//printf("connected: %d\n",connected);
	//menu_destroy(patch_menu);
}


static void parse_patch()
{
	FILE *patch_file;
	char line[100];
	char *w;
	char *c;

	//printf("loading patch: %s\n",pd_patch);
	patch_file = fopen(pd_patch,"r"); 
	if (patch_file == NULL) {
		return;
	} else {
		do { 
			c = fgets(line, 100 ,patch_file); // read a line
			if (c != NULL) {
				if ((strstr(line,"floatatom")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_NUMBER;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->w = 7*atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->h = 16*screen_multiplier;
					strtok(NULL," "); strtok(NULL," "); strtok(NULL," "); strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));

					widget_count++;
				} if ((strstr(line,"symbolatom")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_SYMBOL;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->w = 7*atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->h = 16*screen_multiplier;
					strtok(NULL," "); strtok(NULL," "); strtok(NULL," "); strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));

					widget_count++;
				} else if ((strstr(line,"vsl")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_VSLIDER;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," ");
					pd_widget[widget_count]->w = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->h = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->min = atoi(strtok(NULL," "));
					pd_widget[widget_count]->max = atoi(strtok(NULL," "));
					strtok(NULL," "); strtok(NULL," "); strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));

					widget_count++;
				} else if ((strstr(line,"hsl")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_HSLIDER;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," ");
					pd_widget[widget_count]->w = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->h = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->min = atoi(strtok(NULL," "));
					pd_widget[widget_count]->max = atoi(strtok(NULL," "));
					strtok(NULL," "); strtok(NULL," "); strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));

					widget_count++;
				} else if ((strstr(line,"vradio")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_VRADIO;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," ");					
					pd_widget[widget_count]->w = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," "); strtok(NULL," ");
					pd_widget[widget_count]->min=0;
					pd_widget[widget_count]->max=atoi(strtok(NULL," "));
					pd_widget[widget_count]->h = pd_widget[widget_count]->w*pd_widget[widget_count]->max;
					strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));
					pd_widget[widget_count]->max--;

					widget_count++;
				} else if ((strstr(line,"hradio")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_HRADIO;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," ");
					pd_widget[widget_count]->h = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," "); strtok(NULL," ");
					pd_widget[widget_count]->min=0;
					pd_widget[widget_count]->max=atoi(strtok(NULL," "));
					pd_widget[widget_count]->w = pd_widget[widget_count]->h*pd_widget[widget_count]->max;
					strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));
					pd_widget[widget_count]->max--;

					widget_count++;
				} else if ((strstr(line,"bng")!=NULL) && (strstr(line,"pod_")!=NULL)) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_BANG;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					strtok(NULL," ");
					pd_widget[widget_count]->w = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->h = pd_widget[widget_count]->w;
					strtok(NULL," "); strtok(NULL," "); strtok(NULL," "); strtok(NULL," ");
					sprintf(pd_widget[widget_count]->name,"%s",strtok(NULL," "));
					pd_widget[widget_count]->min=0;
					pd_widget[widget_count]->max=1;

					widget_count++;
				} else if (strstr(line,"text")!=NULL) {
					pd_widget[widget_count] = (WIDGET*)malloc(sizeof(WIDGET));
					pd_widget[widget_count]->type=PD_TEXT;

					strtok(line," "); strtok(NULL," ");
					pd_widget[widget_count]->x = atoi(strtok(NULL," "))*screen_multiplier;
					pd_widget[widget_count]->y = atoi(strtok(NULL," "))*screen_multiplier;
					
					sprintf(pd_widget[widget_count]->name,"%s ",strtok(NULL," "));

					w=strtok(NULL," ");
					while (w!=NULL) {
						strcat(pd_widget[widget_count]->name,w);
						strcat(pd_widget[widget_count]->name," ");
						w=strtok(NULL," ");
					} pd_widget[widget_count]->name[strlen(pd_widget[widget_count]->name)-3] = '\0';

					widget_count++;
				}
			}
		}  while (c != NULL);
	}
	fclose(patch_file);
	loaded = 1;
}

// start the pd process
static void start_pd() {
	
	pd_pid = vfork();
	
	if (pd_pid == 0) {
		execl (pd_command,"pd","-r","22050","-nogui","-rt","-nomidi","-noadc",pd_patch, NULL);
		new_message_window("failed to start pure data engine");
		_exit(0); // if exec fails exit the forked process.
	} else if (pd_pid < 0) return; // failed to fork
		
	// printf("started pd with pid: %d\n",pd_pid);
	running = 1;

}

// connect to the pd process
static void connect_pd() {

	struct hostent *hp;
	struct sockaddr_in server_out,server_in;

	// sending
	sockfd_out = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd_out < 0) return;

	hp = gethostbyname("127.0.0.1");
	if (hp == 0) return;

	server_out.sin_family = AF_INET;
	memcpy((char *)&server_out.sin_addr, (char *)hp->h_addr, hp->h_length);
	server_out.sin_port = htons(3333);

	if (connect(sockfd_out, (struct sockaddr *) &server_out, sizeof (server_out)) < 0)
	{
		close(sockfd_out);
		return;
	}

	// receiving
	sockfd_in = socket(AF_INET, SOCK_DGRAM, 0);
	if (sockfd_in < 0) return;

	server_in.sin_family = AF_INET;
	server_in.sin_addr.s_addr = INADDR_ANY;
	server_in.sin_port = htons(3334);

	if (bind(sockfd_in, (struct sockaddr *)&server_in, sizeof(server_in)) < 0)
	{
		close(sockfd_in);
		return;
	}

	pd_timer_id = GrCreateTimer (pdpod_wid, 50);
	connected = 1;
}

// stop the pd process
static void stop_pd() {
	int status, result;
	result = kill( pd_pid, SIGKILL);
	wait(&status);
	running = 0;
}


// connect to the pd process
static void disconnect_pd() {

	GrDestroyTimer(pd_timer_id);
	close(sockfd_out);
	close(sockfd_in);
	connected = 0;
}


// send pause & wait
static void pause_pd() {

	char pause_message[10];

	draw_status();
	sprintf(pause_message,"p %d;\n",!paused);
	send_message(pause_message);

	while (paused) {
		check_event();
		usleep(100);
	}
}

// send a message to pd
static int send_message(char *message) {

	//printf("sending message: %s\n",message);
	int res = send(sockfd_out, message, strlen(message), 0);
	if (res < 0) {
		//printf("failed sending message: %s\n",message);
		return 0;
	}
	return 1;
}

// read messages from pd
static void read_messages() {

	char buf[1024];
	char update;
	int ret;

	struct timeval timeout;
	fd_set fdSocket;

	timeout.tv_sec = 0;
	timeout.tv_usec = 0;
 
 	FD_ZERO(&fdSocket);
  	FD_SET(sockfd_in, &fdSocket);

	update=0;
	while (select (sockfd_in+1, &fdSocket, NULL, NULL, &timeout)) {
		ret = recv(sockfd_in, buf, 1024, 0);
		if (ret > 0) {
			char *line = strtok(buf,"\n");
			while (line!=NULL) {
				//printf("%s\n",line);
				char *message = strtok(buf,";");
				while (message!=NULL) {
					process_message(message);
					update=1;
					message = strtok(NULL,";");
				} line = strtok(NULL,"\n");
			}
		}
 	}

	if (update) draw_gui();
}

static void process_message(char *message) {
	int i;
	char *object=NULL;
	char *argument=NULL;
	float argval = 0;

	object = strtok(message," ");
	argument = strtok(NULL," ");
	
	if (argument!=NULL)  argval = atof(argument);

	//printf("%s %f\n",object,argval);
	
	for (i=0;i<widget_count;i++) {
		if(strncmp(object, pd_widget[i]->name, strlen(pd_widget[i]->name)) == 0) {
			if (pd_widget[i]->type!=PD_NUMBER) {
				if (argval>pd_widget[i]->max) argval=pd_widget[i]->max;
				if (argval<pd_widget[i]->min) argval=pd_widget[i]->min;
			}
			
			if (pd_widget[i]->type==PD_BANG) pd_widget[i]->value=1;
			else pd_widget[i]->value=argval;
		}
	}

}

// check for events & delete the event queue
static void check_event() {
		if (GrPeekEvent(&break_event)) { 
			GrGetNextEventTimeout(&break_event, 1000);
			if (break_event.type != GR_EVENT_TYPE_TIMEOUT) {
				pz_event_handler(&break_event);
				// delete the rest of the event queue
				while ( break_event.type != GR_EVENT_TYPE_NONE ) {
					if (break_event.type == GR_EVENT_TYPE_KEY_DOWN) {
					switch (break_event.keystroke.ch) {
						case 'l': 
							scroll_value--;
							break;
						case 'r': 
							scroll_value++;
							break;
						default:
							break;
					} } 
					if (break_event.type == GR_EVENT_TYPE_TIMER) draw_status();
					GrCheckNextEvent(&break_event);
				}
			}
		}
}

// clean up & quit
static void pdpod_quit() {
	menu_destroy(patch_menu);
	pz_close_window(pdpod_wid);
	pz_close_window(status_wid);
	GrDestroyTimer(cpu_timer_id);
	GrDestroyWindow(pdpod_wid);
	GrDestroyWindow(status_wid);
	GrDestroyWindow(pdpod_buffer);
	GrDestroyWindow(status_image);
	GrDestroyWindow(pause_image);
	GrDestroyGC(pdpod_gc);	
}

// handle  events
static int handle_event(GR_EVENT *event)
{
    int ret = 0;
    char scroll_message[32];
    switch (event->type)
    {
		case GR_EVENT_TYPE_TIMER:
			if(running) {
				if(event->timer.tid==cpu_timer_id) draw_status();
				if(event->timer.tid==pd_timer_id) read_messages();
			}
			break;

		case GR_EVENT_TYPE_KEY_DOWN:
			switch (event->keystroke.ch)
			{
				case IPOD_BUTTON_MENU:
					if (running) {
						if (shift) {
							send_message("q;\n");
							disconnect_pd();
							stop_pd();
							free_memory();
							init_values();
							draw_status();
							draw_gui();
						} else if (!paused) {
							send_message("m 1;\n");
							if (widget_count==0)  {
								menu_button=1;
								draw_gui();
							}
						}
					} else if (about) pdpod_quit();
					else about=1;
					break;
				case IPOD_BUTTON_ACTION:
					if(about) { about=0; draw_gui(); }
					else if (!loaded) load_patch();
					else {
						if (!paused)  {
							//shift=1;
							//new_message_window("action");
							send_message("b;\n");
							if (widget_count==0)  {
								action_button=1;
								draw_gui();
								usleep(10000);
								action_button=0;
								draw_gui();
							}
						} shift = 1;
					}
					break;
				case IPOD_BUTTON_REWIND:
					if (!paused) {
						send_message("w 1;\n");
						if (widget_count==0)  {
							rewind_button=1;
							draw_gui();
						}
					}
					break;
				case IPOD_BUTTON_FORWARD:
					if (!paused) {
						send_message("f 1;\n");
						if (widget_count==0)  {
							forward_button=1;
							draw_gui();
						}
					}
					break;
				case IPOD_WHEEL_COUNTERCLOCKWISE:
					if (!loaded) {
						patch_id--;
						if(patch_id<0) patch_id=0;
						draw_gui();
					} else if (!paused) {
						scroll_value--;
						scroll_diff = abs(last_scroll - scroll_value);
						last_scroll = scroll_value;
						sprintf(scroll_message,"l %d;\n", scroll_diff);
						send_message(scroll_message);
						if (widget_count==0) draw_gui();
					}
					break;
				case IPOD_WHEEL_CLOCKWISE:
					if (!loaded) {
						patch_id++;
						if(patch_id>menu_entries) patch_id=menu_entries;
						draw_gui();
					} else if (!paused) {
						scroll_value++;
						scroll_diff = abs(last_scroll - scroll_value);
						last_scroll = scroll_value;
						sprintf(scroll_message,"r %d;\n", scroll_diff);
						send_message(scroll_message);
						if (widget_count==0) draw_gui();
					}
					break;
				case IPOD_BUTTON_PLAY:
					if (shift) {
						paused=!(paused);
						pause_pd();
					} else if (!paused) {
						send_message("d 1;\n");
						if (widget_count==0) {
							play_button=1;
							draw_gui();
						}
					}
				case IPOD_SWITCH_HOLD:
					ret |= KEY_UNUSED;
					break;
				default:
					ret |= KEY_UNUSED;
					break;
			}
			break; 
		case GR_EVENT_TYPE_KEY_UP:
			switch (event->keystroke.ch)
			{
				case IPOD_BUTTON_MENU: // Menu button.
					if ((!shift) && (!paused)) {
						send_message("m 0;\n");
						if (widget_count==0) {
							menu_button=0;
							draw_gui();
						}
					}
					break;
				case IPOD_BUTTON_ACTION: // action butten
					shift=0;
					break;
				case IPOD_BUTTON_REWIND:
					if (!paused) {
						send_message("w 0;\n");
						if (widget_count==0) {
							rewind_button=0;
							draw_gui();
						}
					}
					break;
				case IPOD_BUTTON_FORWARD:
					if (!paused) {
						send_message("f 0;\n");
						if (widget_count==0) {
							forward_button=0;
							draw_gui();
						}
					}
					break;
				case  IPOD_WHEEL_COUNTERCLOCKWISE: 
					ret |= KEY_UNUSED;
					break;
				case  IPOD_WHEEL_CLOCKWISE:
					ret |= KEY_UNUSED;
					break;
				case IPOD_BUTTON_PLAY:
					if ((!shift) && (!paused)) {
						send_message("d 0;\n");
						if (widget_count==0) {
							play_button=0;
							draw_gui();
						}
					}
				case IPOD_SWITCH_HOLD:
					ret |= KEY_UNUSED;
					break;
				default:
					ret |= KEY_UNUSED;
					break;
			}
			break; 
		default:
			ret |= EVENT_UNUSED;
			break;
    }
	return ret;
}



