#define MWINCLUDECOLORS
#include "nano-X.h"
#include "messages.h"
#include "graphics.h"
#include "memory.h"

void error_event(GR_EVENT *event);


void close_message()
{
	messages.enabled=0;
	paint();
	}

void error_message(char *message)
{
	int w, h, b, rand, i=-1, letzte=0, letzte_passende=0;
	char *mit_wort;
	rand= MESSAGE_BOX_RAND;
	mit_wort=get_mem(sizeof(char)*(strlen(message)+1));
	messages.message= get_mem(sizeof(char)*(strlen(message)+1));
	strcpy(messages.message, message);
	messages.height= ZEILEN_ABSTAND+2*rand;
	messages.width=0;
	while (message[++i]!='\0')
	{
		if (message[i]==' ')
		{
			GrGetGCTextSize(gc, mit_wort, -1, 0, &w, &h, &b);
			if (w > screen_info.cols-(RAND_AUSSEN_MESSAGE_WINDOW*2)-(MESSAGE_BOX_RAND*2) && letzte!=0) //pr�fen ob Zeilenumbruhh n�tig
			{
				messages.message[letzte]='\n';
				letzte= 0;
				*mit_wort='\0';
				messages.height+=ZEILEN_ABSTAND;
				if (messages.width < letzte_passende)
				{
					messages.width= letzte_passende;
					}
				}
			else {
				letzte_passende=w+rand*2;
				letzte= i;
				strncat(mit_wort, &message[i], 1);
				}
			}
		else if (message[i]=='\n')
		{
			GrGetGCTextSize(gc, mit_wort, -1, 0, &w, &h, &b);
			if (messages.width < w+rand)
			{
				messages.width= w+rand;
				}
			letzte= 0;
			*mit_wort='\0';
			messages.height+=ZEILEN_ABSTAND;
			}
		else
		{
			strncat(mit_wort, &message[i], 1);
			}
		}
	GrGetGCTextSize(gc, mit_wort, -1, 0, &w, &h, &b);
	if (messages.width < w+rand)
	{
		messages.width= w+rand*2;
		}
	printf("%s\n", message);
	messages.top= (screen_info.rows-messages.height)/2;
	messages.left= (screen_info.cols-messages.width)/2;
	messages.text_top= messages.top+messages.height-rand-h+b;
	messages.enabled= 1;
	messages.type=ERROR_MESSAGE;
	paint_message();
	}
