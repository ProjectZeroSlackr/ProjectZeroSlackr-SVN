#define MWINCLUDECOLORS
#include "nano-X.h"
#include "graphics.h"
#include "messages.h"
#include "logic.h"
#include <stdio.h>
#include "menus/menus.h"


void event_handler (GR_EVENT *event);

extern int menu_enabled;

int main (void)
{
	if (GrOpen() < 0)
	{
	fprintf (stderr, "GrOpen failed");
	exit (1);
	}

	gc = GrNewGC();
	GrSetGCUseBackground (gc, GR_FALSE);
	GrSetGCForeground (gc, WHITE);
	GrGetScreenInfo(&screen_info);

	wid = GrNewWindowEx (GR_WM_PROPS_APPFRAME |
			GR_WM_PROPS_CAPTION  |
			GR_WM_PROPS_CLOSEBOX,
			"ipod-desktop",
			GR_ROOT_WINDOW_ID,
			0, 0, screen_info.cols, screen_info.rows, BLACK);

	GrSelectEvents (wid, GR_EVENT_MASK_EXPOSURE |
			GR_EVENT_MASK_CLOSE_REQ |
			GR_EVENT_MASK_KEY_DOWN);
	menu_set_gc(gc);
	menu_set_wid(wid);
	menu_set_screen_info(screen_info);
	menu_set_fonts();
	menu_load_from_file("/usr/local/4wins/menu");
	srand(time(0));
	set_fonts();
	new_game();
	GrMapWindow (wid);
	GrMainLoop (event_handler);
}

void event_handler (GR_EVENT *event)
{
	switch (event->type)
	{
	case GR_EVENT_TYPE_KEY_DOWN:
		if (messages.enabled==1)
		{
			close_message();
			}
		else if (menu_enabled==1)
		{
			switch (event->keystroke.ch)
			{
				case 'm':
					menu_close();
					menu_paint();
					break;
				case 'r':
					menu_move_down();
					break;
				case 'l':
					menu_move_up();
					break;
				case '\r':
					menu_execute();
				}
			}
		else
		{
			switch (event->keystroke.ch)
			{
				case 'm':
					menu_enabled=1;
					menu_paint();
					break;
				case 'r':
					move_right();
					break;
				case 'l':
					move_left();
					break;
				case '\r':
					execute_stone();
				}
			}
		break;

	case GR_EVENT_TYPE_EXPOSURE:
		paint();
		if (menu_enabled==1)
		{
			menu_paint();
			}
		if (messages.enabled==1)
		{
			paint_message();
			}
		break;

	case GR_EVENT_TYPE_CLOSE_REQ:
		GrClose();
		exit (0);
		break;
	}
}
