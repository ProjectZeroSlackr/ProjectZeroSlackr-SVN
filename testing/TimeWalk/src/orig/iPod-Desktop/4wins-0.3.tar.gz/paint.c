#define MWINCLUDECOLORS
#include "nano-X.h"
#include "graphics.h"
#include "messages.h"
#include "logic.h"



int menu_font;
int ueberschrift_font;
int platz_vor_ueberschrift;
int platz_ueber_ueberschrift;


int image_stone[3];
int image_pfeil;
int image_turn[3];


void paint_message()
{
	int rand, x=ZEILEN_ABSTAND, i=-1;
	char *text;
	text= (char *)get_mem(sizeof(char)*(strlen(messages.message+1)));
	*text= '\0';
	rand= MESSAGE_BOX_RAND;
	GrSetGCForeground(gc, BLACK);
	GrFillRect(wid, gc, messages.left+1, messages.top+1, messages.width-2, messages.height-2);
	GrRect(wid, gc, messages.left-1, messages.top-1, messages.width+2, messages.height+2);
	GrSetGCForeground(gc, WHITE);
	GrRect(wid, gc, messages.left, messages.top, messages.width, messages.height);
	while (messages.message[++i]!='\0')
	{
		if (messages.message[i]=='\n')
		{
			GrText(wid, gc, messages.left+ rand, messages.top+MESSAGE_BOX_RAND+x-1, text, -1, GR_TFASCII);
			x+= ZEILEN_ABSTAND;
			*text= '\0';;
			}
		else
		{
			strncat(text, &messages.message[i], 1);
			}
		}
	GrText(wid, gc, messages.left+ rand, messages.top+MESSAGE_BOX_RAND+x-1, text, -1, GR_TFASCII);
	}


void set_fonts(void)
{
	int w, h, b;
	menu_font= GrCreateFont("", MENU_SCHRIFT_HOEHE, 0);
	GrSetFontSize(menu_font, MENU_SCHRIFT_HOEHE);
	ueberschrift_font= GrCreateFont("", UEBER_SCHRIFT_HOEHE, 0);
	GrSetFontSize(ueberschrift_font, UEBER_SCHRIFT_HOEHE);
	GrSetGCFont(gc, ueberschrift_font);
	GrGetGCTextSize(gc, "ipod-desktop", -1, 0, &w, &h, &b);
	platz_vor_ueberschrift= (screen_info.cols-w)/2;
	platz_ueber_ueberschrift= (PLATZ_OBEN-2-b)/2+b;
	image_stone[0]=GrLoadImageFromFile("/usr/local/4wins/0.gif", 0);
	if (!(image_stone[1]=GrLoadImageFromFile("/usr/local/4wins/1.gif", 0)))
	{
		error_message("Bild konnte nicht geladen werden");
		}
	image_stone[2]=GrLoadImageFromFile("/usr/local/4wins/2.gif", 0);
	image_pfeil=GrLoadImageFromFile("/usr/local/4wins/pfeil.gif", 0);
	image_turn[1]=GrLoadImageFromFile("/usr/local/4wins/turn_1.gif", 0);
	image_turn[2]=GrLoadImageFromFile("/usr/local/4wins/turn_2.gif", 0);
	}



void paint_head(void)
{
	GrSetGCForeground(gc, BLACK);
	GrFillRect(wid, gc, 0, 0, 140, 8);
	GrDrawImageToFit(wid, gc, 20*position, 0, 20, 8, image_pfeil);
	}


void paint_right(void)
{
	GrSetGCForeground(gc, BLACK);
	GrFillRect(wid, gc, 140, 0, 20, 128);
	GrDrawImageToFit(wid, gc, 141, 20, 18, 18, image_turn[player]);
	}

void paint(void)
{
	int i, ii;
	paint_head();
	paint_right();
	for (i=0;i<7;i++)
	{
		for (ii=0;ii<6;ii++)
		{
			paint_stone(i, ii);
			}
		}
	}

void paint_stone(int i, int ii)
{
	GrDrawImageToFit(wid, gc, i*20, 8+ii*20, 20, 20, image_stone[stones[i][ii]]);
	}
