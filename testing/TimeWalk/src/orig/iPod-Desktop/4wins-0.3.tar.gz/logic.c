#include "logic.h"
#include "graphics.h"
#include "messages.h"
#include "singleplayer.h"

int move=2;
int singleplayer;

void move_left(void)
{
	if (move>=MOVE_SPACE)
	{
		move=0;
		if (position!=0)
		{
			position--;
			paint_head();
			}
		}
	else
	{
		move++;
		}
	}

void move_right(void)
{
	if (move==0)
	{
		move=MOVE_SPACE;
		if (position!=6)
		{
			position++;
			paint_head();
			}
		}
	else
	{
		move--;
		}
	}

void execute_stone(void)
{
	int i;
	char message[24];
	if (ende == 0)
	{
		strcpy(message, "Spieler 0 hatt gewonnen");
		i=-1;
		while (stones[position][i+1]==0 && i!=5)
		{
			i++;
			}
		if (i!=-1)
		{
			stones[position][i]=player;
			paint_stone(position, i);
			zuge--;
			if (search_for_win(player))
			{
				ende=1;
				message[8]= player+'0';
				error_message(message);
				}
			else if (zuge==0)
				{
					ende=1;
					error_message("unentschieden");
					}
			else
			{
				player= player ^ (1^2);
				paint_right();
				if (singleplayer == 1)
				{
					computer_play();
					paint_right();
					if (search_for_win(player^ (1^2)))
					{
						ende=1;
						message[8]= player ^ (1^2)+'0';
						error_message(message);
						goto stop;
						}
					}
				if (zuge==0)
				{
					ende=1;
					error_message("unentschieden");
					}
				}
			}
		}
	stop:
	}

void new_game(void)
{
	int i;
	int ii;
	position=0;
	player=1;
	zuge=42;
	ende=0;
	for (i=0; i<7; i++)
	{
		for (ii=0; ii<6; ii++)
		{
			stones[i][ii]=0;
			}
		}
	}

int search_for_win(int player)
{
	int i;
	int ii;
	int res;
	for (i=0; i<7; i++)
	{
		for (ii=0; ii<6; ii++)
		{
			if ((search_stones(player, i, ii, 0)==4) || (search_stones(player, i, ii, 1)==4) || (search_stones(player, i, ii, 2)==4) || (search_stones(player, i, ii, 3)==4))
			{
				return 1;
				}
			}
		}
	return 0;
	}

int search_stones(player, i, ii, richtung)
{
	int a, b, c, res=0;
	switch (richtung)
	{
		case 0:
		case 1:
		case 7:
			a=1;
			break;
		case 3:
		case 4:
		case 5:
			a=-1;
			break;
		case 2:
		case 6:
			a=0;
		}
	switch (richtung)
	{
		case 1:
		case 2:
		case 3:
			b=1;
			break;
		case 5:
		case 6:
		case 7:
			b=-1;
			break;
		case 0:
		case 4:
			b=0;
		}
	if (((i+a*3<0) || (i+a*3>6) || (ii+b*3<0) ||(ii+b*3>5)) || ((i<0) || (i>6) || (ii<0) ||(ii>5)))
	{
		return -1;
		}
	else
	{
		for (c=0; c<4; c++)
		{
			if (stones[i][ii]==player)
			{
				res++;
				}
			else
			 if (stones[i][ii]!=0)
			{
				return -1;
				break;
				}
			i+=a;
			ii+=b;
			}
		return res;
		}
	}
