void computer_play(void);
