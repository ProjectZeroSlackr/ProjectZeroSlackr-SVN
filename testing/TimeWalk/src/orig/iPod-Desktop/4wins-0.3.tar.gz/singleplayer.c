#include "logic.h"
#include <stdlib.h>
#include <limits.h>

struct row_points
{
	int good;
	int bad;
	};

void computer_play(void)
{
	int i;
	int row;
	struct row_points rows[8]={-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, INT_MAX};
	int best=7, count_best=1;
	int me_ap[5]= {0, 43, 9331, 2015539, 347734933};
	int me_bp[5]= {0, 1, 259, 55987, 12093235};
	int otherp[5]= {0, 7, 1555, 335923, 20454996};
	int *me_a, *me_b, *other;
	me_a=me_ap;
	me_b=me_bp;
	other=otherp;
	me_a++;
	me_b++;
	other++;
	for (row=0;row<7;row++)
	{
		i=-1;
		while (stones[row][i+1]==0 && i!=5)
		{
			i++;
			}
		if (i!=-1)
		{

			rows[row].good=points_for_point(row, i, player, me_a);
			rows[row].good+=points_for_point(row, i, player ^ (1^2), other);
			if (i!=0)
			{
				stones[row][i]=player;
				rows[row].bad=points_for_point(row, i-1, player, me_b);
				rows[row].bad+=points_for_point(row, i-1, player ^ (1^2), other);
				stones[row][i]=0;
				}
			if (rows[row].good>=rows[row].bad)
			{
				if (rows[row].good>rows[best].good)
				{
					best= row;
					count_best=1;
					}
				else if (rows[row].good==rows[best].good)
				{
					if (rows[row].bad<rows[best].bad)
					{
						best= row;
						count_best=1;
						}
					else if (rows[row].bad==rows[best].bad)
					{
						count_best++;
						}
					}
				}
			else if (rows[best].good<rows[best].bad)
			{
				if (rows[row].bad<rows[best].bad)
				{
					best= row;
					count_best=1;
					}
				else if (rows[row].bad==rows[best].bad)
				{
					if (rows[row].good>rows[best].good)
					{
						best= row;
						count_best=1;
						}
					else if (rows[row].good==rows[best].good)
					{
						count_best++;
						}
					}
				}
			}
		}
	if (count_best!=1)
	{
		count_best=rand()/(RAND_MAX+1.0)*count_best-0.5;
		i=-1;
		for (row=0;i!=count_best;row++)
		{
			if ((rows[row].good==rows[best].good) && (rows[row].bad==rows[best].bad))
			{
				i++;
				}
			}
		best= row-1;
		}
	i=-1;
	while (stones[best][i+1]==0 && i!=5)
	{
		i++;
		}
	stones[best][i]=player;
	paint_stone(best, i);
	zuge--;
	player= player ^ (1^2);
	}

points_for_point(int x, int y, int player, int points[4])
{
	int point=0;
	int before=0;
	point= points[search_stones( player,x-3, y, 0)];
	point+= points[search_stones( player,x-2, y, 0)];
	point+= points[search_stones( player,x-1, y, 0)];
	point+= points[search_stones( player,x, y, 0)];
	point+= points[search_stones( player,x-3, y-3, 1)];
	point+= points[search_stones( player,x-2, y-2, 1)];
	point+= points[search_stones( player,x-1, y-1, 1)];
	point+= points[search_stones( player,x, y, 1)];
	point+= points[search_stones( player,x, y-3, 2)];
	point+= points[search_stones( player,x, y-2, 2)];
	point+= points[search_stones( player,x, y-1, 2)];
	point+= points[search_stones( player,x, y, 2)];
	point+= points[search_stones( player,x+3, y-3, 3)];
	point+= points[search_stones( player,x+2, y-2, 3)];
	point+= points[search_stones( player,x+1, y-1, 3)];
	point+= points[search_stones( player,x, y, 3)];
	return point;
	}
