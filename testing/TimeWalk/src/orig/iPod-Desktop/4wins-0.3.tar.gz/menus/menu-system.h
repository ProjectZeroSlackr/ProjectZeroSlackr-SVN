#define SYSTEM_REBOOT 1
#define SYSTEM_QUIT 2
#define SYSTEM_BACKLIGHT 3

void menu_execute_system(int system_id);
void menu_set_wid(int awid);
void menu_set_gc(int agc);
void menu_set_screen_info(GR_SCREEN_INFO ascreen_info);
