#include "nano-X.h"

#define ZEILEN_HOEHE 17
#define MENU_SCHRIFT_HOEHE 11
#define UEBER_SCHRIFT_HOEHE 19
#define MAX_ZEILEN 6
#define PLATZ_VOR_ZEILE 17
#define PLATZ_OBEN 26
#define SCROLL_BAR_BREITE 3
#define MINDEST_HOEHE_SCROLL_BAR 5
#define MESSAGE_BOX_RAND 3
#define RAND_AUSSEN_MESSAGE_WINDOW 2
#define ZEILEN_ABSTAND 12

GR_WINDOW_ID  wid;
GR_GC_ID      gc;
GR_SCREEN_INFO screen_info;

void menu_set_font(void);
void menu_paint(void);
void menu_paint_zeile(int zeile, int position);
void menu_paint_scroll_bar(void);
