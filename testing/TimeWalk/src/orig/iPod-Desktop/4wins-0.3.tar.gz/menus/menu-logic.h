#define MENU_TYPE_FILE 1
#define MENU_TYPE_MENU 2
#define MENU_TYPE_SYSTEM 3
#define MENU_NORMAL_USE -1;

union menu_location {
	char *file;
	struct menu_system *menu;
	int system;
	};

struct menu_eintrag {
	char *name;
	int image;
	int image_selected;
	int type;
	union menu_location location;
	};

extern struct menu_system {
	struct menu_system *parent;
	char *name;
	int count;
	int position;
	int scrolling;
	struct menu_eintrag *eintrag;
	} *menu;


void set_menu_logic();
void menu_move_up();
void menu_move_down();
void menu_execute();
int menu_load(char *file, struct menu_system** menu);
int menu_load_from_file(char *file);
void menu_close();
