

void *get_mem(int bytes)
{
	return (void *) malloc(bytes);
	}

typedef struct menu_eintrag* p_eintrag;

struct menu_system
*get_menu_system(int anzahl, char *name, struct menu_system *menu)
{
	struct menu_system *menu_a;
	menu_a= (struct menu_system *) get_mem(sizeof(struct menu_system)+sizeof(struct menu_eintrag) * (anzahl)+sizeof(char)*(strlen(name)+1));
	menu_a->count= 0;
	menu_a->position=0;
	menu_a->scrolling=0;
	menu_a->parent= menu;
	menu_a->eintrag= (struct menu_eintrag *) (&(menu_a->eintrag)+1);
	menu_a->name= (char *) (menu_a->eintrag+anzahl);
	strcpy(menu_a->name, name);
	return menu_a;
	}
