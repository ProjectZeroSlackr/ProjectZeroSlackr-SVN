void *get_mem(int bytes);
struct menu_system *get_menu_system(int anzahl, char* name, struct menu_system *menu);
