



int menu_font;
int ueberschrift_font;
int platz_vor_ueberschrift;
int platz_ueber_ueberschrift;

void menu_set_fonts(void)
{
	menu_font= GrCreateFont("", MENU_SCHRIFT_HOEHE, 0);
	GrSetFontSize(menu_font, MENU_SCHRIFT_HOEHE);
	ueberschrift_font= GrCreateFont("", UEBER_SCHRIFT_HOEHE, 0);
	GrSetFontSize(ueberschrift_font, UEBER_SCHRIFT_HOEHE);
	GrSetGCFont(gc, ueberschrift_font);
	}

void set_header_space(void)
{
	int w, h, b;
	GrGetGCTextSize(gc, menu->name, -1, 0, &w, &h, &b);
	platz_vor_ueberschrift= (screen_info.cols-w)/2;
	platz_ueber_ueberschrift= (PLATZ_OBEN-2-b)/2+b;
	}

void menu_paint(void)
{
	int i;
	GrSetGCForeground (gc, BLACK);
	GrFillRect(wid, gc, 0, 0, screen_info.cols, PLATZ_OBEN-2);
	GrLine(wid, gc, 0, PLATZ_OBEN-1, screen_info.cols, PLATZ_OBEN-1);
	GrSetGCForeground (gc, WHITE);
	GrLine(wid, gc, 0, PLATZ_OBEN-2, screen_info.cols, PLATZ_OBEN-2);
	GrSetGCFont(gc, ueberschrift_font);
	GrText(wid, gc, platz_vor_ueberschrift, platz_ueber_ueberschrift, menu->name, -1, GR_TFASCII);
	for (i=-1; ++i < MAX_ZEILEN && i+menu->scrolling < menu->count;)
	{
		menu_paint_zeile(i+menu->scrolling, i*ZEILEN_HOEHE);
		}
	menu_paint_scroll_bar();
	}


void menu_paint_zeile(int zeile, int position)
{int breite;
	if (menu->count > MAX_ZEILEN)
	{
		breite= screen_info.cols- SCROLL_BAR_BREITE;
		}
	else
	{
		breite= screen_info.cols;
		}
	if (menu->position==zeile)
	{
		GrSetGCForeground (gc, WHITE);
		GrFillRect(wid, gc, 0, position + PLATZ_OBEN, breite, ZEILEN_HOEHE);
		GrSetGCForeground (gc, BLACK);
		if (menu->eintrag[zeile].image_selected!=0)
		{
			GrDrawImageToFit(wid, gc, 1, position+PLATZ_OBEN+1, 15, 15, menu->eintrag[zeile].image_selected);
			}
		}
	else
	{
		GrSetGCForeground (gc, BLACK);
		GrFillRect(wid, gc, 0, position + PLATZ_OBEN, breite, ZEILEN_HOEHE);
		GrSetGCForeground (gc, WHITE);
		if (menu->eintrag[zeile].image!=0)
		{
			GrDrawImageToFit(wid, gc, 1, position+PLATZ_OBEN+1, 15, 15, menu->eintrag[zeile].image);
			}
		}
	GrSetGCFont(gc, menu_font);
	GrText(wid, gc, PLATZ_VOR_ZEILE, position+(ZEILEN_HOEHE-MENU_SCHRIFT_HOEHE)/2+MENU_SCHRIFT_HOEHE + PLATZ_OBEN, menu->eintrag[zeile].name,  -1, GR_TFASCII);
	}



void menu_paint_scroll_bar(void)
{
	int hoehe_scroll_bar;
	int position_scroll_bar;
	if (menu->count > MAX_ZEILEN)
	{
		hoehe_scroll_bar= (screen_info.rows-PLATZ_OBEN)/menu->count*MAX_ZEILEN;
		if (hoehe_scroll_bar<MINDEST_HOEHE_SCROLL_BAR)
		{
			hoehe_scroll_bar= MINDEST_HOEHE_SCROLL_BAR;
			}
		position_scroll_bar= PLATZ_OBEN+(screen_info.rows-PLATZ_OBEN-hoehe_scroll_bar)/(menu->count-MAX_ZEILEN)*menu->scrolling;
		GrSetGCForeground (gc, BLACK);
		GrFillRect(wid, gc,
			screen_info.cols-SCROLL_BAR_BREITE-1,
			PLATZ_OBEN,
			screen_info.cols,
			position_scroll_bar-PLATZ_OBEN);
		GrFillRect(wid, gc,
			screen_info.cols-SCROLL_BAR_BREITE-1,
			position_scroll_bar+hoehe_scroll_bar+1,
			screen_info.cols,
			screen_info.rows-position_scroll_bar-hoehe_scroll_bar);
		GrLine(wid, gc, screen_info.cols-SCROLL_BAR_BREITE-1, position_scroll_bar, screen_info.cols-SCROLL_BAR_BREITE-1, position_scroll_bar+hoehe_scroll_bar);
		GrSetGCForeground (gc, WHITE);
		GrFillRect(wid, gc,
			screen_info.cols-SCROLL_BAR_BREITE,
			position_scroll_bar,
			SCROLL_BAR_BREITE,
			hoehe_scroll_bar);
		}
	}
