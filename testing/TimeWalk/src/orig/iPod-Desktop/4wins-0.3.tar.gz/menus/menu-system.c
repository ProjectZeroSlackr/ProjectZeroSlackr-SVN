#include <fcntl.h>
#ifdef IPOD
#include <linux/fb.h>
#endif
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern int menu_enabled;
extern int singleplayer;

void new_game(void);
void paint(void);
void computer_play(void);

#define FBIOSET_BACKLIGHT _IOW('F', 0x25, int)

void menu_execute_system(int system_id)
{
	static int backlight;
	switch (system_id)
	{
		case 1:
			menu_enabled=0;
			paint();
			break;
		case 2:
			menu_enabled=0;
			new_game();
			singleplayer=0;
			paint();
			menu_close();
			break;
		case 3:
			GrClose();
			exit(0);
			break;
		case 4:
			menu_enabled=0;
			new_game();
			singleplayer=1;
			paint();
			menu_close();
			break;
		case 5:
			menu_enabled=0;
			new_game();
			singleplayer=1;
			computer_play();
			paint();
			menu_close();
		}
	}

void menu_set_wid(int awid)
{
	wid= awid;
	}

void menu_set_gc(int agc)
{
	gc=agc;
	}

void menu_set_screen_info(GR_SCREEN_INFO ascreen_info)
{
	screen_info=ascreen_info;
	}
