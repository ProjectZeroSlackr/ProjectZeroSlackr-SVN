#define MOVE_SPACE 3
void move_left(void);
void move_right(void);
void execute_stone(void);
void new_game(void);

int position;
int ende;
int stones[7][6];
int player;
int zuge;
