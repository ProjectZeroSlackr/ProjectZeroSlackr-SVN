/*
 Owen OS Remix

 
  Created by Owen McGarry on 7/5/06.
 
 //===================================================\\
 || Ported to the iPod by Sergiusz Bazanski on 29 of July 2006  ||
 \\===================================================//
 
  Copyright 2006 __Clubhouse engineers__. All rights reserved.
 
 */

#include <stdio.h>
#include <stdlib.h>
#define VER 7.0
typedef char bool; 
#define true 1 
#define false 0

	int game;
	int alarm;
	int water;
	int socks;
	int fork;
	int mobile;
	int tavern;
	int music;
	int slugs;
	int win;
	int home;
	int battle;
	int slap;
	//Gasp
	char gamec;
	char alarmc;
	char waterc;
	char socksc;
	char forkc;
	char mobilec;
	char tavernc;
	char musicc;
	char slugsc;
	char winc;
	char homec;
	char battlec;
	char slapc;

void pause(); //Prototyping functions.  You forgot about that!
void gamehandler();
void gameover();

int main() 
{
printf("\n\n"); 
  int word;
	int word2;
    int maininput;
	char mainchar;
	int phrase;
	
 
  bool exit = false; 

  while (exit == false) 
  { 
    printf("\aWelcome To Owen O.S. version %.1f\n", VER);
	printf("\nEnter the shown number into the command input window to open that file or applacation\n\n");
	
	
	printf("Center. About\n");
	printf("Rewind. Random facts\n");
	printf("FF. Translator\n");
	printf("Menu. Clear screen\n");
	printf("Play. Games list\n");
	printf("Hold. Exit\n\n");
    scanf(" %c", &mainchar);

	if (mainchar == '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		maininput = 1;
	else if (mainchar == 'w')
		maininput = 2;
	else if (mainchar == 'f')
		maininput = 3;
	else if (mainchar == 'm')
		maininput = 4;
	else if (mainchar == 'd')
		maininput = 5;
	else if (mainchar == 'h')
		maininput = 6;
		
	


    switch(maininput) 
    { 
      case 1: 
        about(); 
        break; 

      case 2: 
        randomfacts(); 
        break; 

      case 3: 
        translator(); 
        break; 

      case 4: 
        system("clear"); 
        break; 

      case 5: 
        gamehandler(); 
        break; 

      case 6: 
        exit = true; 
        break; 

      default: 
        printf("\nDon't press the wheel, doh."); 
        break; 
    } //End of switch statement 
  } //End of main while loop 
  
  return 0; 
} //End of main() 




int about()
{
printf("\n\nOwen O.S. Version %.1f\n", VER);
		printf("Coded 2006 by Owen McGarry\n");
		printf("Ported to the iPod by Sergiusz Bazanski\n");
		printf("GNU copyright laws apply\n");
		main();
}


translator()
{
	int lingo;
	char lingoc;

	system("clear");
	printf("Welcome to the translator.\n\n");
	printf("Choose a option:\nCenter. Italian\nRewind. Welsh\nFF. Phrase book\nMenu. Exit\n\n");
	scanf(" %c", &lingoc);
	
	if (lingoc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		lingo = 1;
	else if (lingoc ==  'w')
		lingo = 2;
	else if (lingoc ==  'f')
		lingo = 3;
	else if (lingoc ==  'm')
		lingo = 4;

if (lingo == 1)
{
printf("A\n");
printf("Artichoke - carciofo\n\n");
printf("B\n");
printf("Bassoon - fagotto\n");
printf("Belly Button - ombelico\n");
printf("Bishop - vescovo\n\n");
printf("C\n");
printf("Caterpillar - bruco\n");
printf("Chandelier - lampadario\n\n");
printf("D\n");
printf("Dismount - scendere\n");
printf("Do-It-Yourself - fare da s�\n\n");
printf("E\n");
printf("Easel - cavalletto\n\n");
printf("F\n");
printf("Fridge � frigorifero\n\n");
printf("G\n");
printf("Good Grief! - uffa!\n\n");
printf("H\n");
printf("Hammock - amaca\n");
printf("Hippopotamus � ippopotamo\n");
pause();
printf("Hydromassage - idromassaggi\n\n");
printf("I\n");
printf("Intercom � interfono\n");
printf("In a nutshell � in poche parole\n\n");
printf("J\n");
printf("Juggernaut � bestione\n\n");
printf("K\n");
printf("Kangaroo � canguro\n");
printf("Kebab � spiedino\n");
printf("Kilt � gonnellino scozzese\n\n");
printf("L\n");
printf("Lavender � lavanda\n");
printf("Lizard � lucertola\n");
printf("Leek - porro\n");
printf("Lollypop - lecca-lecca\n");
printf("Lop-sided � non equilibrato\n");
printf("Lozenge - pastiglia\n\n");
printf("M\n");
printf("Mallet � maglio\n");
printf("Mantlepiece � mensola del caminetto\n");
printf("Marzipan � marzapone\n");
pause();
printf("Mating Call � richiamo sessuale\n");
printf("Meatball � polpetta di carne\n");
printf("Moustache - baffi\n\n");
printf("N\n\n");
printf("O\n");
printf("Ostrich - struzzo\n\n");
printf("P\n");
printf("Paddock � prato reciatato\n");
printf("Pianist � pianista\n");
printf("Prod � colpetto\n");
printf("Puppet - burattino\n\n");
printf("Q\n");
printf("Quack � qua qua (duck)\n");
printf("Quadrangle � cortile\n");
printf("Qualm � dubbio\n\n");
printf("R\n");
printf("Raccoon � procione\n");
printf("Rudder � timone\n");
printf("Rumpus � baccano\n\n");
printf("S\n");
printf("Seaworthy � atto alla navigazione\n");
pause();
printf("Ski sticks - racchette\n");
printf("Spoon - cucchiaio\n\n");
printf("T\n");
printf("Tambourine � tamburello\n");
printf("Thermal - termico\n");
printf("Toothpick � stuzzicadenti\n\n");
printf("U\n");
printf("Udder� mammella\n\n");
printf("V\n");
printf("Volcano � vulcano\n\n");
printf("W\n");
printf("Whale � balena\n");
printf("What are you doing? - che stai facendo?\n");
printf("What the hell is happening? - che cavolo succede?\n");
printf("Whisk � frullino\n");
printf("Willy-nilly � volente o nolente\n\n");
printf("X\n\n");
printf("Y\n");
printf("Yeast � lievito\n");
printf("You're a liar! - sei un bugiardo!\n\n");
printf("Z\n");
main();
}
if (lingo == 2)
{
printf("A\n");
printf("Acorn - mesen\n");
printf("Alas - ow\n");
printf("Alien - estronol\n");
printf("Alien Woman - estrones\n");
printf("Almighty - hollalluog/hollgyfoethog\n");
printf("Aloof - pell\n");
printf("Apron - arffedog\n");
printf("Arch Bishop - archesgob\n\n");
printf("B\n");
printf("Badger - broch\n");
printf("Balladmonger - baledwr\n");
printf("Bamboozle - llygad-dynnu\n");
printf("Bearded - barfog\n");
printf("Buffalo - bual\n");
printf("By God! - myn duw!\n\n");
printf("C\n");
printf("Cardigan - aberteifi\n");
printf("Coffin - arch\n");
printf("Coinage - bathiad\n\n");
printf("D\n");
pause();
printf("Dandelion - dant y llew\n");
printf("Dentistry - deintyddiaeth\n");
printf("Dormouse - pathew\n");
printf("Dropkick - cic adlam\n\n");
printf("E\n");
printf("Elasticity - hydwythedd\n");
printf("Empty oneslef - ymwaca\n");
printf("Eyelid - amrant\n\n");
printf("F\n");
printf("Female Swan - alarches\n");
printf("Flock of Sheep - cail\n");
printf("Frolic - campio\n\n");
printf("G\n");
printf("Gather Acorns - mesa\n");
printf("Gather Snails - malwenna\n");
printf("Gauntlet - dyrnfol\n");
printf("Girdle - gwregys\n\n");
printf("H\n");
printf("Harpoon - tryfer\n\n");
printf("I\n");
printf("Index finger - mynegtys\n\n");
pause();
printf("J\n\n");
printf("K\n\n");
printf("L\n\n");
printf("M\n\nn");
printf("N\n");
printf("Napkin - napcyn\n\n");
printf("O\n");
printf("Ostrich - estrys\n");
printf("O dear me! - o'r annwyl!\n\n");
printf("P\n");
printf("Prick up the Ears - clustfeinio\n\n");
printf("Q\n\n");
printf("R\n\n");
printf("S\n\n");
printf("Silly Woman - ffolog\n");
printf("Sheep - defaid\n");
printf("Sheep with Young - mamog\n");
printf("Stroke of a Weapon - arfod\n\n");
printf("T\n");
printf("Tall Awkward Fellow - carwden\n");
printf("Tinker - eurych\n");
pause();
printf("Turnip - erfinen\n");
printf("Twitter - yswitian\n\n");
printf("U\n");
printf("Under my Roof - tan fy nghronglwyd\n\n");
printf("V\n");
printf("Vocalist - lleisiwr\n");
printf("Vowel - llafariad\n\n");
printf("W\n\n");
printf("X\n\n");
printf("Y\n\n");
printf("Z\n");
main();
}
if (lingo == 3)
{
printf("English-Spanish\n\n");
printf("Can I light a fire here? - �Puedo encender fuego aqu�?\n");
printf("Hey Jimmy, there's a gas leak! - �Hoy Jimmy, el gas se est� saliendo!\n");
printf("I'll have a peice of that cheese - Quiero un trozo de ese queso\n");
printf("I would like to take water-skiing lessons - Quer� dar clases de esqu� acu�tico\n");
printf("Where are your mini shorts? -  �D�nde estas t�s pantalones peque�os?\n");
printf("Where can I rent a Petticoat? - �D�nde puedo alquilar una combinaci�n?\n");
printf("This elefant meat is very spicey, I need another glass of apricot juice - �La carne de elefante est� muy picante!  Nescito otro vaso de jugo de albaricoque\n");
printf("My mustache hurts when you touch it - Mi bigote me duele al tocarlo\n\n\n");
printf("English-French\n\n");
printf("Excuse me, I seem to have dropped my spoon - Excusez-moi, je semblent avoir laiss� tomber ma cuill�re\n");
printf("Hey, Jimmy, can you pass that monkey wrench? - H�, Jimmy, pouvez-vous passer cette cl� de singe?\n");
printf("So much for the afterglow - Tellement pour la postluminescence\n");
printf("Yuk! That cheese stinks! - Beuhrk! Ce fromage pue!\n"); //A little correction from my part. I speak english like native ;)
printf("Would you like a sausage? -  Vous aimeriez avoir une saucisse?\n");  //Here too
printf("Quickly Jeeves, I've found the capers! - Rapidement Jeeves, j'ai trouv� les c�pres!\n");
printf("Hurry, the ladder! The bed is on fire! - H�te, l'�chelle! Le lit est en feu!\n"); //And here
printf("I think this mango may be sour. Fetch me another - Je pense cette mangue peux �tre pas tres mure. Cherchez-moi un autre\n");  //Also here
printf("Oh bugger I've broken my spectacles - Eh zut! J'ai  cass� mes lunettes\n\n\n"); //Here
printf("English-Norwegian\n\n");
printf("Clear the area. The helicopter is about to crash - ��V�r s� snill og rydd omr�det. Helikopteret om krasjer\n");
printf("The treasure is gone! - Skatten dradd!\n");
printf("Train six is now arriving at platform two hundred and twenty for and a half - Utdann seks n� ankommer p� plattform to hundre og tjue for og en halvdel\n");
printf("Don't touch the acid! It's highly alkali! - Ber�r ikke syren! Det er meget alkali!\n");
printf("Our next lot is Africa, and attractive, large property, priced at three hundred billion pounds - V�r neste tomt er Africa, og tiltrekkende, stor eiendom, som prissatt p� tre hundre milliardpund.\n");
printf("Have you looked behind the sofa? -  Ha De som sett bak sofaen?\n");
printf("There ain't no beer in cow horn creek - Der ain' t ingen �l i kuhornelv\n\n\n");
printf("English-Italian\n\n");
printf("Keep left for the Gospel Hall - La conservazione ha andato per il Gospel Corridoio\n");
printf("There's no business like show business - Non ci � il commercio come il commercio di esposizione\n");
printf("For credible advice about starting a business visit Business Link - Per consiglio credibile circa iniziare un collegamento di affari di chiamata di affari\n");
printf("Hey, Sammy, nice umbrella - Hey, Sammy, ombrello piacevole\n");
printf("The grass is always greener where its been properly looked after and cultivated - L'erba � sempre pi� verde dove relativa occupata di e coltivata correttamente\n");
printf("To Be or not to Be, that is the question - Essere o non essere, quella � la domanda\n");
printf("Excuse me, but why has my shopping been sent to Uganda? - Lo scusa, ma perch� il mio shopping � stato trasmesso nell'Uganda?\n");
printf("Excuse me please, I very much like your telephone - Scusilo per favore, io molto gradiscono il vostro telefono\n");
main();
}

if (lingo == 4)
{
main();
}
}


randomfacts()
{
printf("\n\nThe Animal Kingdom\n\n");
printf("- The Average Speed of a Snail : 0.06 m/s 0.02 km/h 0.013 mph.\n");
printf("- The Elephant is the only mammal which cannot jump.\n");
printf("- You can only lead cows up stairs, but not down.\n");
printf("- A snail can sleep for 3 years.\n");
printf("- The average blue whale's tongue weighs the same as an elephant.\n");
printf("- The Queen owns every swan in England.\n");
printf("- 1 in every 5000 North Atlantic Lobsters are born bright blue.\n\n\n");
printf("Interesting Science\n\n");
printf("- Enzymes like it warm, but not too warm.\n"); 
printf("- A jelly is one big molecule.\n");
pause();
printf("- The very first computer ever made weighed 27 tonnes and was invented by Sir Charles Babbage.\n");
printf("- If you collected 10 billion clouds, you could get 1 teaspoon of water.\n" );
printf("- It's impossible to lick your elbow[without dislocateing it].\n");
printf("- A cough comes out of your mouth at an average 60mph.\n");
printf("- The largest snowflake ever measured was 15 inches [measured in 1886].\n");
printf("- If you hum at the same frequency as a TV channel that you are watching, horizontal lines will appear on the screen that only you will be able to see.\n\n\n");
printf("Potty Talk\n\n");
printf("- Human excrement mixed with fairy liquid explodes when lit.\n");
printf("- All the toilet paper used in Japan in one day would stretch 10 times around the equator.\n\n\n");
printf("Religion\n\n");
printf("- The Bible has been translated into Klingon\n\n\n");
printf("Economics\n\n");
printf("- Everyday more money is printed for Monopoly than for the US treasury.\n");
}

void gamehandler() //It's a void, d'oh
{

//The declareation part is gone. It should reside somewhere else.
	
system("clear");
	printf("Games:\n\n");
	printf("Center. Burton\n");
	printf("Rewind. *unnamed*\n");
	printf("FF. Exit\n");
	printf("More games to come!\n\n");
	scanf(" %c", &gamec);
	
	if (gamec ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		game = 1;
	else if (gamec ==  'w')
		game = 2;
	else if (gamec ==  'f')
		game = 3;
	
	if (game == 3)
	{main();}
	
	if (game == 2)
{


system ("clear");
printf("Your name is Jeff this time.\n");
printf("You are a compolsive twnkie addict.\n");
printf("You pass a MOBILE mart(tm) what do you do?\n\n");


printf("Center. Go in and buy a twinkie\nRewind. Rob the place\nFF. keep walking\n\n");
scanf(" %c", &mobilec);

	if (mobilec ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		mobile = 1;
	else if (mobilec ==  'w')
		mobile = 2;
	else if (mobilec ==  'f')
		mobile = 3;


if (mobile == 1)
{
printf("You buy the twinkie\n\n");
sleep (1);
printf("\a*weight +1*\n\n");
}
if (mobile == 2)
{
printf("You steal some twinkies\n\n");
sleep (1);
printf("\a*weight +2*\n\n");
}
if (mobile == 3)
{
printf("You know what this is already getting boreing\nI don't like you anymore, you looze...");
gameover();
}

printf("You walk contentedly along munching your twinkie\n");
printf("you see three shops which do you enter?\n\n");
printf("Center. The gun shop\n");
printf("Rewind. The gym\n");
printf("FF. The tavern\n\n");
scanf(" %c", &tavernc);

	if (tavernc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		tavern = 1;
	else if (tavernc ==  'w')
		tavern = 2;
	else if (tavernc ==  'f')
		tavern = 3;



if (tavern == 1)
{
printf("You enter the gun shop but didn't notice the large sign saying:\n\n\tBE WARE\n\tCrazy guy with gun\n\n");
printf("You get shot, tough luck");
sleep (2);
gameover();
}
if (tavern == 2)
{printf("Too bad, you enter the tavern\n");}
if (tavern == 3)
{printf("You enter the crowed tavern aparently there is a concert by one, Dr. Yodel and the Bagpipe Troupe\n");}

printf("You are in the tavern what do you do?\n\n");
printf("Center. Stay and listen to the music\nRewind. Promptly exit the area\n\n");
scanf(" %c", &musicc);

	if (musicc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		music = 1;
	else if (musicc ==  'w')
		music = 2;


if (music == 1)
{
printf("As soon as the melodic sounds of Dr. Yodel and the bagpipe troupe reach your ears, you die from horror.\n");
printf("GAME OVER");
gamehandler();
}
if (music == 2)
{printf("You exit, man that music sucked...\n");}



printf("Some, how you say,");
sleep (2);
printf(" ah yes, slimy slug guys, attempt to mug you\nWhat do you do?\n\n");
printf("Center. Find salt\nRewind. Use your kung fu\nFF. Run like heck\n\n");
scanf(" %c", &slugsc);

	if (slugsc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		slugs = 1;
	else if (slugsc ==  'w')
		slugs = 2;
	else if (slugsc ==  'f')
		slugs = 3;

if (slugs == 1)
{
printf("Wow, its lucky you carry around that sack of sea salt in your purse\n");
printf("You wonder what purse we speek of...\n");
}
if (slugs == 2)
{
printf("What kung fu!?! you never learned kung fu!!\n");
gameover();
}
if (slugs == 3)
{
printf("You know what this is already getting boreing\nI don't like you anymore, you looze...");
gameover();
}


printf("After ditching the purse in the nearest grabage can you:\n");
printf("Center. Find some more twinkies\nRewind. Go home\nFF. Learn kung fu\n\n");
scanf(" %c", &homec);

	if (homec ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		home = 1;
	else if (homec ==  'w')
		home = 2;
	else if (homec ==  'f')
		home = 3;
if (home == 1)
{
printf("You stop at the nearest twinkie dealer and head home\n");
}
if (home == 2)
{
printf("You go home\n");
gameover();
}
if (home == 3)
{
	printf("Hey look you just spotted Hung Lee's kung fu shoppe\n");
	printf("You step inside\n");
	printf("Hung Lee sees you enter\n");
	printf("He asks \"what you want to do, eh?\"\n\nCenter. Sign up\nRewind. Chalange him to a battle\n\n");
	scanf(" %c", &battlec);
	if (battlec ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		battle = 1;
	else if (battlec ==  'w')
		battle = 2;

		if (battle == 1)
		{
		printf("You sign up for lessonds\n");
		printf("He chlanges you to a battle to test your 'skilz'\n");
		}
	printf("The battle begins; Lee starts with a quick roundhouse kick\n");
	printf("what you want to do?  Crap, now I am talking like him!\n\n");
	printf("Center. Right punch\nRewind. Left punch\nFF. Right kick\nMenu. Left kick\nPlay. Right slap\nHold. Left slap\n\n");
	scanf(" %c", &slapc);
	
	if (slapc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		slap = 1;
	else if (slapc ==  'w')
		slap = 2;
	else if (slapc ==  'f')
		slap = 3;
	else if (slapc ==  'm')
		slap = 4;
	else if (slapc ==  'd')
		slap = 5;
	else if (slapc == 'h')
		slap = 6;
		if (slap == 1)
		{
		printf("Aah dang, too slow.\n");
		gameover();
		}
		if (slap == 2)
		{
		printf("Aah dang, too slow.\n");
		gameover();
		}
		if (slap == 3)
		{
		printf("Aah dang, too slow.\n");
		gameover();
		}
		if (slap == 4)
		{
		printf("Aah dang, too slow.\n");
		gameover();
		}
		if (slap == 5)
		{printf("You slap him and amazingly he gets KO'd\n\n**YOU WIN THE BATTLE**\n\nthen you go home");}
		if (slap == 6)
		{
		printf("Aah dang, too slow.\n");
		gameover();
		}
}

printf("You get back home and unlock the door");


printf("\n*programmer gets lazy*\n\n"); //Hehe
printf("What do you do?\n\nCenter. Win game\nRewind. Loose game\n");
scanf(" %c", &winc);

	if (winc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		win = 1;
	else if (winc ==  'w')
		win = 2;

if (win == 1)
{
printf("\n\n\t\a\aYOU WIN!!!");
gamehandler();
}
if (win == 2)
{
printf("Why would you do that?!?");
gameover();
}


gamehandler();
}
	
	if (game == 1)
{

//I'm getting kinda bored, 664 lines already. Oh well.

printf("Welcome to Burton's Revenge: the Quest of the Twisted Hat and his Playing Cards.\n\n");
sleep (1);
printf("One fateful morning, your alarm goes off. When you look up, however, it says BU:RTon instead of 8:22am!\n");
printf("what do you do? \nCenter. press snooze, \nRewind. turn on radio or \nFF. utilize cricket bat\n");
  scanf(" %c", &alarmc);
  
  	if (alarmc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		alarm = 1;
	else if (alarmc ==  'w')
		alarm = 2;
	else if (alarmc ==  'f')
		alarm = 3;
  
   if (alarm == 1)
   {printf("You are suddenly teleported away into a dark cave with dim torches lighting the area.\nYou look around and see the skulls of many dead animalia.\n");}
   
   if (alarm == 2)
   {
    printf("As soon as the melodic sounds of Dr. Yodel and the bagpipe troupe reach your ears, you die from horror.\n"); //ROFLMAO'd
    printf("GAME OVER!\n");
	main();
	}
	
   if (alarm == 3)
   {
    printf("The cricket bat accidentally turns on the radio. As soon as the melodic sounds of Dr. Yodel and the bagpipe troupe reach your ears, you die from horror.\n");
    printf("GAME OVER!");
	 main();
	}

printf("You see a glass of water on the floor.  What do you do?  \nCenter. drink, \REwind. spill it or \FF. utilize cricket bat\n");
scanf(" %c", &waterc);

	if (waterc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		water = 1;
	else if (waterc ==  'w')
		water = 2;
	else if (waterc ==  'f')
		water = 3;


   if (water == 3)
   {
    printf("A shard of glass hits you at high velocity and you die.\n");
    printf("GAME OVER!\n");
	main();
	}
	
   if (water == 1)
   {printf("The cup is one of those joke glasses with holes in it so you spill water everywhere. Then some guy named Chad emerges from the spillage.\n");}
   
   if (water == 2)
   {
   printf("A man made of water - a water man - jumps out at you, you proceed to soil yourself.\n");
   }

printf("He aks you if you are wearing thermal foot regulating contraptions - socks. What is your response? \nCenter. Yes, \Rewind. No or \FF. Only on my left foot\n");
  scanf(" %c", &socksc);
  	if (socksc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		socks = 1;
	else if (socksc ==  'w')
		socks = 2;
	else if (socksc ==  'f')
		socks = 3;

  
  printf("He says, \"Okay, great\".\n");  //WTF? Where's the rest of the code? You lazyass ;)
  
  
printf("You see a fork in a road, where the term 'fork in the road' here refers to an eating utensil stuck in the middle of a path.\nWhat do you do? \nCenter. Pull it out, \nRewind. Walk around, \nFF. stomp it into the ground\n");
scanf(" %c", &forkc);

	if (forkc ==  '\r') //TODO: Make this whole codeblock a little bit more elegant ;)
		fork = 1;
	else if (forkc ==  'w')
		fork = 2;
	else if (fork ==  'f')
		forkc = 3;

  
   if (fork == 1)
   {printf ("You reach over and gently dislodge the fork.  As soon as you do this dramatic music starts playing (Dum! Dum! Dummmmmm!) and you are wisked away to the Round Table\n.");
    
	if (fork == 2)
	{
    printf("You walk around the fork. Suddenly, dramatic music begins playing and you die.\n");
    printf("GAME OVER!\n");
	 main();
	}

	if (fork == 3)
	{
		printf("You jump onto the fork with all your might. Suddenly, dramatic music begins playing and you die.\n");
		printf("GAME OVER!\n");
		 main();
	}

printf("A man clad in fifth-century European armoury walks up to you.\n\"Hello,\" he says, 'I am Sir Burton.  I have been following you while you were embarking on my quest.'\n");
  sleep (1);
printf("He cleared his throat. You look at him expectantly, and he begins to speak:\n");
printf("The first telephone pole art piece appeared around 1994 along the southbound lane of Rt. 23 near Smoke Rise, New Jersey.\nA plastic pumpkin sat atop a 30 ft. utility pole, grinning to passers-by. Slowly other\ncharacters began showing up atop the poles along that stretch road: a chicken, a bowling\npin, a two foot tall beer bottle, a mail box, a rabbit, a flamingo, and a bright\npink pig, were all perched on consecutive low voltage telephone poles. Nobody seemed to know\nwho was placing them there, though, making their strange appearance even more perplexing to the local residents.\n");
  sleep (5);
printf("That's where you came in. I was relying on you to find the culprit. So I followed you around, hiding inside my guize of\na misunderstood ferret. I discovered that Kinnelon Mayor Glen Sisco said the poles drew mixed\nreactions from the townsfolk. Kinnelon police Capt. Elmer Bott said in the newspaper\nthat except for one anonymous complaint about the poles distracting motorists,\nthe poles haven�t caused any problems. However, he stated that the exhibit was illegal, citing\na law prohibiting affixing anything to utility poles.\n");
  sleep (5);
printf("Do you see where I'm heading?' he asks.\n");
  sleep (1);
printf("Not really,' you respond.\n");
  sleep (1);
printf("Well, you will. Soon. Very Soon. Anyway, Whoever is responsible has more recently been decorating the poles in a\nmuch more highly visible area of Route 23, near Canistear Road.\nYes, just as the Kinnelon grouping of pole ornaments began to fade due to weathering, their mysterious mounter\nsurprised everyone by starting a whole new group a few miles farther north, on the poles that\nborder the Oak Ridge Reservoir. Now West Milford residents are feeling the draw of the pole\nart, where a metal whale and a plastic cat were the first in what would\nsoon be a long line of roadside attractions. Soon to follow: a witch, a gnome,\na rubber chicken, Big Bird, a Mutant Ninja Turtle, a snowman,\na ball and chain, Mr. Peanut, an alien, and the list goes on and on.\n");
  sleep (5);
printf("You can see that the situation was getting much worse. There was even an effort made to remove all of\nthe offending ornaments from the poles in question. But what do you think happened?\nThat's right, just as soon as they were taken down, a new series of different pieces went up!\nIt would almost seem that this renegade pole-hopping craftsman was on some kind of a weird mission.\nBut what do these weird creations represent? A strange telephone pole cult? An homage to some\nforgotten lineman? Or just someone with too much free time?\n");
  sleep (5);
printf("I finally found out who it was, mainly thanks to you. The name, unfortuately, is classified, but let's just say\nthat the culprit lives\nbetween Virginia and Maryland in a big white house.' \n");
  sleep (5);
printf("By helping to identify this villan,' said Burton, 'You have proven yourself far beyond your third cousin twice\nremoved's uncle's expectations.\n");
sleep (1);
printf("CONGRAGURATIONS! I DUB YOU SIR KOOL.' \n");
  sleep (5);
printf("You Win!");
sleep (5);
main();

}//ends game
	
   
}//ends game runner
}//ends function


void gameover()
{
printf("\n\nGAME OVER\n");
printf("Yeah, try again man\n\n\n");
sleep (3);
gamehandler();
}

void pause() //Used to pause text printing, needed because of iPod's lack to scroll text up and down.
{
	printf("\nPress action.");
	char button;
	do
	{
		scanf(" %c", &button);
	} 
	while (button == '\r');	
}

//Yeah! I'm finished! Bowchickenbowbow!