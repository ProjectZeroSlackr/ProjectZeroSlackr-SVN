
bin/nano-X & bin/launcher bin/launcher.cnf
