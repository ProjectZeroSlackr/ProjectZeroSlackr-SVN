#include "windows.h"

int
MwUserInit(int ac,char **av)
{
	return 0;
}
