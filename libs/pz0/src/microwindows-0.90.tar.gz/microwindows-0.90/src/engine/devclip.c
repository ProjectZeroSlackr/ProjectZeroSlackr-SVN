#include "device.h"

#if DYNAMICREGIONS
#include "devclip2.c"
#else
#include "devclip1.c"
#endif
