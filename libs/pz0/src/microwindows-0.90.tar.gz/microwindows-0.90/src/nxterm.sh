
# Nano-X applications, press <BREAK> key to exit
bin/nano-X -A $1 & bin/nxscribble & bin/nanowm & bin/nxkbd & bin/nxterm & bin/nxterm & bin/nxroach -roaches 10 & sleep 10000
