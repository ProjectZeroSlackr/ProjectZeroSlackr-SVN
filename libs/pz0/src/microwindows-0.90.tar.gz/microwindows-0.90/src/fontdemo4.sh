
# Nano-X applications, press <BREAK> key to exit
bin/nano-X & bin/nanowm & bin/t1demo
