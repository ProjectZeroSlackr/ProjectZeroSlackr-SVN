#!/bin/sh
# Check if Mac or Linux
if [ `uname` == "Darwin" ]; then
	./ipodpatcher-mac -ab loader.bin
else
	./ipodpatcher -ab loader.bin
fi
# No idea how to implement a check if successful or not
rm -rf ipodpatcher*
rm -rf loader.bin
read -p "Press any key to exit . . ."
rm -rf patch*