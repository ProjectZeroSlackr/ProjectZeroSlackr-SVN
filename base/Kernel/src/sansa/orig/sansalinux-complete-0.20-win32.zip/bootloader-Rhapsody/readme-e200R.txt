To install the SansaLinux-bootloader on an e200R(Rhapsody),
you have to copy the pp5022.mi4to the root-dir of your e200R. 
Then it should install.
