#!/bin/sh
#set -vx
#exec >> /var/log/loader2autoexec.log 2>&1

# Called by the rc file since uses "exec"
exec `/bin/getLoader2AutoExec`