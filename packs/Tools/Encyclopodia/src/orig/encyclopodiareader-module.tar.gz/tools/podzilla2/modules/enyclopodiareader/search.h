#include <pz.h>

namespace encyclopodia {

extern TWindow* create_search_window(ttk_menu_item* menu_item);

}
