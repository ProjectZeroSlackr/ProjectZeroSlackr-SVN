#!/bin/bash
mount /dev/sda3 /mnt/tmp
cp darcnes /mnt/tmp/bin
eject /dev/sda

