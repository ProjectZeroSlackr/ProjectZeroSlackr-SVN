                 _____________  __________ __________________ 
                 __  ___/__  / / /___  __ \___  ____/___  __ \
                 _____ \ _  / / / __  /_/ /__  __/   __  /_/ /
                 ____/ / / /_/ /  _  ____/ _  /___   _  _, _/ 
                 /____/  \____/   /_/      /_____/   /_/ |_|  

                ___       _______________   ___________________
                __ |     / /____  _/___  | / /__  ____/__  ___/
                __ | /| / /  __  /  __   |/ / _  / __  _____ \ 
                __ |/ |/ /  __/ /   _  /|  /  / /_/ /  ____/ / 
                ____/|__/   /___/   /_/ |_/   \____/   /____/

                           (C) 2008 Mukunda Johnson

Contents

 1. Hello
 2. How to Play
 3. Multiplayer
 4. Contact

-------------------------------------------------------------------------------
1. Hello
-------------------------------------------------------------------------------

This is my entry for PDROMS CODING COMPETITION #3.99!

I apologize for it being a bit short, I didn't have much time to work on it...
I also ended up having to do the graphics and almost all the music myself. :[

The first boss music was made by coda, hello coda!
The final boss music was made by xaimus, hello xaimus! Thanks for making my
binary >200kb!!

By the way, if you haven't noticed, the music is in IT format! It is replayed
by my fantastic new sound engine. Find out more at www.maxmod.org! :D

BTW, For the best experience, please play this game on an actual GBA!!

-------------------------------------------------------------------------------
2. How to Play
-------------------------------------------------------------------------------

Use the D-Pad to steer your jet to avoid the flashy bullet thingies. :)

Press B to fire at enemies. Collect Powerups (the "P" things that fly around)
to strengthen your firepower.

Press A to launch a big missile that blows up lots of stuff. It also makes you
invulnerable for a short period. You will start with 2 of these with each life.
The "B" pickups will supply you with an extra missile.

If you touch a bullet then you will explode and lose a life! If you have no
more extra lives, (shown in top-left/right corner) the game will end. You may
continue from the beginning of the level (but you lose your score).

-------------------------------------------------------------------------------
3. Multiplayer
-------------------------------------------------------------------------------

If you have a couple GBAs lying about and a multi-player cable, you can have a
second player join the game! When you link the GBAs together (during gameplay)
the game will automatically be transferred to the second GBA and gameplay will
resume with the second player.

The small, purple colored plug is for the host's GBA and the gray large plug
is for the second player's GBA. If the second GBA has a Game Pak inserted, you
must hold Start+Select (during the Nintendo logo screen) to cancel the game
from starting normally.

****************************************
                 NOTICE
 Sorry, but due to time restrictions,
 multiplayer gameplay is NOT implemented
 in this release.
****************************************

-------------------------------------------------------------------------------
4. Contact
-------------------------------------------------------------------------------

Hello's or whatever can be issued here:

E-Mail: mukunda51@hotmail.com
IRC: irc.blitzed.net - #gbadev/#dsdev as eKid
