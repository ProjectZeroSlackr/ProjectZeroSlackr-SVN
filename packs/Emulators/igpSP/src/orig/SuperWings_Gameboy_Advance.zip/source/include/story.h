#ifndef STORY_H
#define STORY_H

void storyPlay( const char* story );

#endif
