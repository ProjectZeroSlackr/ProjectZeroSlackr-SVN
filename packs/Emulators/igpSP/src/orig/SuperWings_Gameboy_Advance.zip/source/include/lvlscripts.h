#ifndef LEVELSCRIPTS_H
#define LEVELSCRIPTS_H

extern u8 script1[];
extern u8 script2[];
extern u8 script3[];

#endif
