#ifndef SECTIONSHHHH
#define SECTIONSHHHH

#define GAMEDATA __attribute__((section("gamedata")))

#endif
