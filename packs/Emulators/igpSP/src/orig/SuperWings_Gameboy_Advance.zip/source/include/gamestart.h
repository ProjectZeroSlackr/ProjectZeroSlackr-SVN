#ifndef GAMESTART_H
#define GAMESTART_H

void showGamestart( void );

#endif
