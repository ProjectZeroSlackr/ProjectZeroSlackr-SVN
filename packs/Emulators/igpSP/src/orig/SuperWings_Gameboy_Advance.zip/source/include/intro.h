#ifndef INTRO_H
#define INTRO_H

void beginIntro( void );

#endif
