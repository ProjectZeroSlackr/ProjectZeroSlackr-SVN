#ifndef TABLES_H
#define TABLES_H

extern s16 sin_tab[];

#endif

