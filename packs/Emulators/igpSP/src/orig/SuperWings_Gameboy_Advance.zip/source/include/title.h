#ifndef TITLE_H
#define TITLE_H

int beginTitle( void );

#endif
