#ifndef STRINGTABLE_H
#define STRINGTABLE_H

extern const char storyline_intro[] ;
extern const char storyline_1[];
extern const char storyline_2[];
extern const char storyline_3[];
extern const char storyline_d1[];
extern const char storyline_d2[];
extern const char storyline_d3[];

#endif
