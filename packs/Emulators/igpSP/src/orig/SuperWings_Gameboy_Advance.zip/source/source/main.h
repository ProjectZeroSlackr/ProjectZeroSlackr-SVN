
#ifndef awefh3th2otih123po61i2h35po1i2h3op12ih351oi23
#define awefh3th2otih123po61i2h35po1i2h3op12ih351oi23
void setPalette( u16* palette );
void copyPalette( int brightness );

#endif
