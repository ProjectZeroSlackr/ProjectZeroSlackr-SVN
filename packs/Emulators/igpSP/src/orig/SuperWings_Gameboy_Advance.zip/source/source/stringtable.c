const char storyline_intro[] = "\
In the year 2086,\x01\x01\x01\x01\r\
war was beginning\x01\x01\x01.\x01\x01\x01.\x01\x01\x01.\r\r\
\x01\x01\x01\x01\x01\x01...\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\r\r\
Somebody set us up the\r\
bomb!\r\
\x01\x01\x01\x01\x01\x01\x01\x01\x01\r\
You,\x01\x01\x01 Christopher Wumbus,\r\
are the only hope left for\r\
this planet.\r\r\x01\x01\x01\x01\x01\x01\
Mount your SUPER WINGS!\r\x01\x01\x01\x01\x01\x01\r\r\
        Good luck!";

const char storyline_1[] = "\
After the island base was\r\
destroyed, you notice that\r\
suddenly those real\r\
headquarters are in\r\
Greenland in somewhere!!\x01\x01\x01\x01\x01\x01\x01\x01\x01\r\
\r\
It is where next you go.\x01\x01\x01\x01\x01\r\
\r\
It is best in the luck!\r\
";


const char storyline_2[] = "\
It is made good!\x01\x01\x01\x01\x01 However,\x01\x01\x01\x01\x01\r\
it is not finished yet!\x01\x01\x01\x01\x01\r\
It was not the real leader\r\
of this organization. \x01\x01\x01\x01\x01The\r\
real leader is positioned\r\
in the stars!!\x01\x01\x01\x01\x01\r\
\r\
Please obtain an a little\r\
rest.\x01\x01\x01\x01\x01 Your final mission\r\
will be in outer space!\r\
";

const char storyline_3[] = "\
The war is finished.\x01\x01\x01\x01\x01 It is\r\
made good!\x01\x01\x01\x01\x01 Thank you for\r\
requiring the time to play\r\
Super Wings.\x01\x01\x01\x01\x01 You may resume\r\
life now.\x01\x01\x01\x01\x01 (Or play again!!)\r\
";

const char storyline_d1[] = "\
It is very sad.\x01\x01\x01\x01\x01 Your Super\r\
Wings that was destroyed\r\
so easily.\x01\x01\x01\x01\x01 This is the end\r\
of the planet earth.\x01\x01\x01\x01\x01\r\r\
I hope that you take after\r\
the good fortune of a\r\
better fortune than the\r\
next time.\r\
";

const char storyline_d2[] = "\
Oh no,\x01\x01\x01\x01\x01 you were killed.\x01\x01\x01\x01\x01\r\
However,\x01\x01\x01\x01\x01 it was good effort.\x01\x01\x01\x01\x01\r\
The more good luck of the\r\
next time!\r\
";

const char storyline_d3[] = "\
You were approaching very\r\
much!\x01\x01\x01\x01\x01 However,\x01\x01\x01\x01\x01 a bad ruler\r\
is remaining yet.\x01\x01\x01\x01\x01 I\r\
recommend it so that you\r\
play once again.\r\
";
