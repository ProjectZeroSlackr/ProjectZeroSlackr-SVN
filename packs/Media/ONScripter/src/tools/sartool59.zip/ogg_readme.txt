THE OggVorbis SOURCE CODE IS (C) COPYRIGHT 1994-2002
by the Xiph.Org Foundation http://www.xiph.org/
