Higurashi no NAku Koro ni DEMO - Onikakushi Day 13, English patch version 1.0, 6/21/2008

Credits:

Translation: Shion
Adaptation: Mion & Shion
Image Editing: Mion
Script Editing: Mion
Beta Testers: Christen, DaCyclops, Ryuuguu Rena, shadowdragon167, Sterling01, SyberiaWinx, tobiast88

TIPS #1,3,4,5,6,8,12,16,17 translation by kj1980.

This patch is brought to you by Sonozaki Futago-tachi.
Have questions or comments?  Check out our blog at
    http://sonozakifutagotachi.blogspot.com/
or email us at
    sonozaki.futagotachi@gmail.com

------------------------------------------------------------------------------------------

HOW TO INSTALL:
1. Create a new folder (say "English") within the original Higurashi Japanese game folder.
2. Place the contents of this patch's zip file into that new folder.
3. Double-click "onscripter-en.exe" to play.

------------------------------------------------------------------------------------------

ONSCRIPTER-EN CONTROLS:
Text Speed:
1: slow
2: normal
3: fast
0: toggle slow/normal/fast

Scrolling:
K/up: move up one option
J/down: move down one option
H/left: go back one page
L/right: go forward one page

Misc:
F: toggle full screen / windowed mode
O: toggle display each page of text instantly
S: toggle fast forward
CTRL: super-fast forward while held down
ESC/right-click: display in-game menu

A: toggle automode (if enabled for game)

left-click/space/return/enter: advance the text (or select a highlighted option)

------------------------------------------------------------------------------------------

Higurashi no Naku Koro ni and all associated material is the copyright of 07th Expansion.

ONScripter-en is licensed under the GNU Public License; see GPL.txt for further information.


