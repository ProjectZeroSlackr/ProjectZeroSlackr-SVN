void bobs_init();
void bobs_frame(long time);
