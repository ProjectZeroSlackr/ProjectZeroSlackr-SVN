/* render text to a sprite bitmap */

#include "sprite.h"

bitmap *render_text(unsigned char** text);
