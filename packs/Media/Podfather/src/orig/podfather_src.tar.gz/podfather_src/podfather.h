#ifndef __PODFATHER_H__
#define __PODFATHER_H__

/* Change these to 138 and 110 if you have a mini! */
#define LCD_WIDTH 160
#define LCD_HEIGHT 128

#define PATTERN 3835

#endif
