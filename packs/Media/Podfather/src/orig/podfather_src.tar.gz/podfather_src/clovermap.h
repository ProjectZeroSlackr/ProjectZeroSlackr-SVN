void clovermap_init();
void clovermap_frame(long time);
