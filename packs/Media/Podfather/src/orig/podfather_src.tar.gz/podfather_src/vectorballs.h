void vectorballs_init();
void vectorballs_frame(long time);
