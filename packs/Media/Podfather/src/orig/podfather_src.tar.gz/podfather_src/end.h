void end_init();
void end_frame(long time);
