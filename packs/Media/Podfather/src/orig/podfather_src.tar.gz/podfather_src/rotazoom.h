void rotazoom_init();
void rotazoom_frame(long time);
