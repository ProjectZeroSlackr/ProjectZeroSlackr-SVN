void rubber_init();
void rubber_frame(long time);
