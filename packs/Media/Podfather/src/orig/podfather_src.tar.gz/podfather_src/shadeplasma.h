void shadeplasma_init();
void shadeplasma_frame(long time);
