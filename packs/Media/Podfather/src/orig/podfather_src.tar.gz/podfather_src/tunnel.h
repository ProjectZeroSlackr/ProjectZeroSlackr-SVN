void tunnel_init();
void tunnel_frame(long time);
