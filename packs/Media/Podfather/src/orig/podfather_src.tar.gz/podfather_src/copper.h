void copper_init();
void copper_frame(long time);
