
iDoom 1.3 - DOOM port for iPod

Web site  : idoom.hyarion.com
Copyright : id Software
Porters   : Benjamin Eriksson (hyarion)
            Mattias  Pierre   (jobbe)
Packager  : Benjamin Eriksson
ReadMe    : Benjamin Eriksson
Released  : November 5:th 2005
Game Type : First Person Shooter



                           New in this version:

* 5g support



                           System Requirements:

iPodLinux enabled: iPod 1g, 2g, 3g 4g, mini 1g, mini 2g,
                        Photo, Color/Colour, nano or 5g(video)



                       Installation Notes (pz0 only):

1)   Make sure iPodLinux is installed on your iPod.
2)   Unzip the zip file.
3)   Copy the iDoom folder to your iPod.
4)   Boot into iPodLinux.
4.1) Select File Browser.
4.2) Scroll down and select the folder "hp" (not needed on mac iPods).
4.3) Scroll down and select the folder "iDoom".
4.4) Start the file iDoom.



                            Default Controls:

In-Game Controls:
 Run   : [Menu]
 Left  : [Rewind]
 Right : [Fast Forward]
 Shoot : [Play/Pause]
 Open  : [Action]
 Menu  : Flip on [Hold], then off again.

Menu Controls:
 Move up      : [Menu]
 Move down    : [Play]
 Select       : [Action]
 Confirm Exit : Rotate the Wheel clockwise
 Cancel       : Flip on [Hold], then off again.


                       Frequently Asked Questions:

1 Q) I can only see a gray blur, how do I change the contrast?
  A) If you change the contrast in podzilla, it will be changed in iDoom too

2 Q) How can I exit iDoom (I'm keep trying to turn the wheel to the right, but that doesn't help)?
  A) Flip [Hold] on, and then off again.
     Press [Menu] to change menu item.
     Select quit(rotate left) then confirm (rotate right).

3 Q) How do I change the controls?
  A) Open the file "keys.key" in your favorite text editor and follow the example in there.

4 Q) How can I switch to next/prev weapon?
  A) This feature was not pressent in the original doom version and are therefore not implemented in iDoom. however this might change in the future.


See the web site ( idoom.hyarion.com ) for a more updated version.


                                Contact Us:

If you want to contact any of the porters, either contact IRC or via E-Mail.
E-Mail  : hyarion@hyarion.com
          mattias.pierre@gmail.com
IRC     : irc.freenode.net # iDoom



                                 Credits:

Blitter             : leachbj/aegray
iPod Photo Testers  : uweenwijfje, petterminator and slowcoder