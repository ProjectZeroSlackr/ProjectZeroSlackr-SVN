#ifndef __FILE__
#define __FILE__

// src is in w_wad.c
int filelength(int fileDesc);

#endif //__FILE__