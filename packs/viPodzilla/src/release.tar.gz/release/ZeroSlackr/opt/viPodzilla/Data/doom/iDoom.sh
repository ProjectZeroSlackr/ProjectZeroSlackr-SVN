#!/bin/sh
cd /opt/viPodzilla/Data/doom
/opt/viPodzilla/Data/doom/iDoom
cd /opt/viPodzilla