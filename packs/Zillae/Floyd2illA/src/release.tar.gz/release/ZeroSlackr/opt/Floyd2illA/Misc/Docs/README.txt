**This Installation is for Windows Only. If you try and**
**install this on a Mac formatted iPod, it will not work**

Floydzilla is a build of Podzilla, done by DansFloyd. 
http://www.ipodlinux.org/Podzilla

ATTENTION:
IF YOU WANT TO PLAY MUSIC WITH LINUX, YOU CANNOT HAVE ANY PODCASTS ON YOUR IPOD 
YOU MUST CLEAR ALL PODCASTS OFF YOUR IPOD, IF YOU WANT TO PLAY MUSIC WITH LINUX

INSTALLING FOR WINDOWS:
For Further Help goto http://dansfloyd.com/help.html

1. Make Sure you have Linux installed on your iPod
2. Run the Floydzilla installer, choose your iPods Drive Letter
3. Once Finished...
4. unmount the iPod, restart (http://ipodlinux.org/key_combinations)
5. Boot into Linux by holding Rewind
6. Read INFO.txt
7. Enjoy! :D 

To get the Power Off feature to work properly:
You need to boot into Floydzilla at least once.
Then restart the ipod and go into Apple's firmware,
You can then reboot back into Floydzilla, 
and the Power off feature should be working.

-----------------------------------------------------------------------------------------
***UPGRADING? no need to uninstall... just overwrite the old with the new, and your up to date***
-----------------------------------------------------------------------------------------
Im allways updateing, so check the website for more info http://www.dansfloyd.com
or the Wiki http://www.ipodlinux.org/FloydZilla
ENJOY!
-----------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------
SPECIAL THANKS TO:
Pokeon, KDE, v1p3r, bholland , jonrelay, the IPL team, and all the guys/gals 
that took the time to write us SWEET apps, games, and hacks!!

   -DansFloyd