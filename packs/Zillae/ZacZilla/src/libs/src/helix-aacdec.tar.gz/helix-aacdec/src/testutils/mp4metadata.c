/*
 *	mp4metadata.c
 *
 *	Read an MP4's Metadata.
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>

#include <mp4ff.h>

void usage(void)
{
	printf("usage:\n");
	printf(" $ mp4metadata infile.mp4\n");
}

uint32_t read_callback(void *user_data, void *buffer, uint32_t length)
{
	return fread(buffer, 1, length, (FILE*)user_data);
}

uint32_t seek_callback(void *user_data, uint64_t position)
{
	return fseek((FILE*)user_data, position, SEEK_SET);
}

int main(int argc, char **argv)
{
	char *filename;
	FILE *infile;
	mp4ff_t *mp4file;
	mp4ff_callback_t *mp4cb;	
	mp4cb = malloc(sizeof(mp4ff_callback_t));
	char *album, *artist, *title;
	time_t tot_time;
	struct tm *tm;
	long len;

	if (argc < 2) {
		usage();
		return -1;
	}
	
	filename = argv[1];

	infile = fopen(filename, "rb");
	if (!infile) {
		printf("Error opening input file: %s\n", filename);
		usage();
		return -1;
	}

	mp4cb->read = read_callback;
	mp4cb->seek = seek_callback;
	mp4cb->user_data = infile;

	mp4file = mp4ff_open_read(mp4cb);
	if (!mp4file) {
		free(mp4cb);
		mp4ff_close(mp4file);
		return -1;
	}

	mp4ff_meta_get_artist(mp4file, &artist);
	mp4ff_meta_get_album(mp4file, &album);
	mp4ff_meta_get_title(mp4file, &title);
	len = mp4ff_get_track_duration(mp4file, 0) / 
	         (mp4ff_time_scale(mp4file, 0) / 1000);

	free(mp4cb);
	mp4ff_close(mp4file);
	fclose(infile);
	
	printf("Artist: %s\n", artist);
	printf("Album: %s\n", album);
	printf("Title: %s\n", title);
	printf("Len: %ld\n", len);

	tot_time = len / 1000;
	tm = gmtime(&tot_time);
	printf("Tm: %02d:%02d:%02d\n", tm->tm_hour, tm->tm_min, tm->tm_sec);

	free(artist);
	free(album);
	free(title);
	
	return 0;
}
