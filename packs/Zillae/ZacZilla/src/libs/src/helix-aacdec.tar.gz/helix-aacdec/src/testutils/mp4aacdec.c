/*
 *	mp4aacdec.c
 *
 *	Read an MP4's AAC track into a buffer, then decode it to pcm.
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>

#include <aacdec.h>
#include <mp4ff.h>

/* options */
#define PROFILE
#define DEBUG

#ifdef DEBUG
#define Dprintf printf
#else
#define Dprintf(...)
#endif

#ifdef PROFILE
#define Pprintf printf
#else
#define Pprintf(...)
#endif

void usage(void)
{
	printf("usage:\n");
	printf(" $ mp4aacdec infile.mp4 [outfile.pcm]\n");
}

int find_first_aac_track(mp4ff_t *infile)
{
	int i, trackType;
	int numTracks = mp4ff_total_tracks(infile);

	for (i = 0; i < numTracks; i++)
	{
		trackType = mp4ff_get_track_type(infile, 0);

		Dprintf("track:%d/%d type:0x%x\n", i, numTracks, trackType);
		
		if (trackType < 0)
			continue;
		if (trackType >= 1 && trackType <= 4) //first aac track.. i think
			return i;
	}

	/* no aac track */
	return -1;
}

uint32_t read_callback(void *user_data, void *buffer, uint32_t length)
{
	return fread(buffer, 1, length, (FILE*)user_data);
}

uint32_t seek_callback(void *user_data, uint64_t position)
{
	return fseek((FILE*)user_data, position, SEEK_SET);
}

static int audiobuf_len;
static unsigned char *audiobuf;
static unsigned short *samplez;
static AACFrameInfo aacFrameInfo;

int mp4_to_raw_aac(FILE *infile)
{
	unsigned char *aacbuf;
	int aacbuf_len;
	mp4ff_t *mp4file;
	mp4ff_callback_t *mp4cb;
	int track, numSamples, sampleId;
	long audiobufpos;
	
	fseek(infile, 0, SEEK_END);
	audiobuf_len = ftell(infile);
	audiobuf = malloc(audiobuf_len); // more than we need
	fseek(infile, 0, SEEK_SET);
	
	mp4cb = malloc(sizeof(mp4ff_callback_t));
	mp4cb->read = read_callback;
	mp4cb->seek = seek_callback;
	mp4cb->user_data = infile;
	
	mp4file = mp4ff_open_read(mp4cb);
	if (!mp4file) {
		free(mp4cb);
		free(audiobuf);
		mp4ff_close(mp4file);
		return -1;
	}

	if ((track = find_first_aac_track(mp4file)) < 0) {
		free(mp4cb);
		free(audiobuf);
		mp4ff_close(mp4file);
		return -2;
	}

	aacbuf = NULL;
	aacbuf_len = 0;
	
	mp4ff_get_decoder_config(mp4file, track, &aacbuf, &aacbuf_len);
	
	aacFrameInfo.nChans = mp4ff_get_channel_count(mp4file, track);
	aacFrameInfo.sampRateCore = mp4ff_get_sample_rate(mp4file, track);
	aacFrameInfo.profile = mp4ff_get_track_type(mp4file, track); // unsure
	
	Dprintf("chans: %d  samprate: %d  profile: 0x%d\n",
	 aacFrameInfo.nChans, aacFrameInfo.sampRateCore, aacFrameInfo.profile);

	numSamples = mp4ff_num_samples(mp4file, track);
	samplez = malloc(sizeof(unsigned short) * numSamples);
	Dprintf("samples: %d\n", numSamples);
	
	aacbuf = NULL;
	aacbuf_len = 0;
	audiobufpos = 0;
	
	for (sampleId = 0; sampleId < numSamples; sampleId++) {
		int rc;
		rc = mp4ff_read_sample(mp4file, track, sampleId, &aacbuf, &aacbuf_len);
		if (rc == 0) {
			if (aacbuf)
				free(aacbuf);
			free(mp4cb);
			free(audiobuf);
			mp4ff_close(mp4file);
			return -3;
		} else {
		memcpy (audiobuf + audiobufpos, aacbuf, aacbuf_len);
		audiobufpos += aacbuf_len;
		samplez[sampleId] = aacbuf_len;
		Dprintf("+b %d (%d == %d) | 0x%x 0x%x ...\n", sampleId, aacbuf_len,
		        samplez[sampleId], aacbuf[0], aacbuf[1]);
		if (aacbuf)
			free(aacbuf);
		}
	}

	free(mp4cb);
	mp4ff_close(mp4file);

	return numSamples;
}

int decode_raw_aac(int numSamples, FILE *outfile)
{
	HAACDecoder *hAACDecoder;
	int newbuf_len, err, stop, sampleId;
	long audiobufpos;
	unsigned char *newbuf;
	static short outBuf[AAC_MAX_NCHANS * AAC_MAX_NSAMPS];
#ifdef PROFILE
	double t1, t2, elapsed;
	struct timeval tp;
	int rtn;
	float audioSecs, audioFrameSecs;

	rtn=gettimeofday(&tp, NULL);
	t1=(double)tp.tv_sec+(1.e-6)*tp.tv_usec;
#endif
	
	hAACDecoder = (HAACDecoder *)AACInitDecoder();
	if (!hAACDecoder) {
		printf("Error initializing decoder.\n");
		usage();
		return -1;
	}
	
	AACSetRawBlockParams(hAACDecoder, 0, &aacFrameInfo);
	
	audiobufpos=0;
	stop = 0;
	err = 0;
	
	
	for (sampleId = 0; sampleId < numSamples; sampleId++)
	{
		newbuf = NULL;
		newbuf_len = 0;
		Dprintf("r %d | ", sampleId);
		fflush(stdout);
		
		newbuf = audiobuf + audiobufpos;
		audiobufpos += samplez[sampleId];
		newbuf_len = samplez[sampleId];
		Dprintf("z 0x%x 0x%x | ", (unsigned int)(audiobuf + audiobufpos),
		         (unsigned int)newbuf);
		fflush(stdout);
		
		Dprintf("| d %d %d | 0x%x 0x%x ...\n", sampleId, newbuf_len,
		        newbuf[0], newbuf[1]);
		fflush(stdout);

		/* decode one AAC frame */
		err = AACDecode(hAACDecoder, &newbuf, &newbuf_len, outBuf);
		
		if (err) {
			/* error occurred */
			Dprintf("e %d \n", err);
			fflush(stdout);
			
			stop = 1;
		}
		if (stop)
			break;
		
		/* no error */
		AACGetLastFrameInfo(hAACDecoder, &aacFrameInfo);

		if (outfile)
			fwrite(outBuf, aacFrameInfo.bitsPerSample / 8,
			       aacFrameInfo.outputSamps, outfile); 
		fflush(outfile);
	}

	AACFreeDecoder(hAACDecoder);
	
	free(audiobuf);
	free(samplez);
	
#ifdef PROFILE
	rtn=gettimeofday(&tp, NULL);
	t2=(double)tp.tv_sec+(1.e-6)*tp.tv_usec;
	elapsed=t2-t1;
	audioFrameSecs = ((float)aacFrameInfo.outputSamps) /
	                 ((float)aacFrameInfo.sampRateOut * aacFrameInfo.nChans);
	audioSecs = (float)(numSamples) * audioFrameSecs;
	Pprintf("song: %f\ndecode: %f\nrealtime: %f\n", audioSecs, elapsed,
			 100 * (audioSecs/elapsed));
#endif
	
	if (err != ERR_AAC_NONE)
		return err;
	
	return 0;
}

int main(int argc, char **argv)
{
	FILE *infile, *outfile;
	char *infileName, *outfileName;
	int raw_samples, dec;

	if (argc < 2) {
		usage();
		return -1;
	}
	
	outfile = 0;
	
	if (argc == 3) {
		outfileName = argv[2];
		outfile = fopen(outfileName, "wb");
		if (!outfile) {
			printf("Error opening output file: %s\n", outfileName);
			usage();
			return -1;
		}
	}
	
	infileName = argv[1];
	
	infile = fopen(infileName, "rb");
	if (!infile) {
		printf("Error opening input file: %s\n", infileName);
		usage();
		return -1;
	}

	Dprintf("decoding %s -> %s\n ", argv[1], argv[2]);

	raw_samples = mp4_to_raw_aac(infile);

	fclose(infile);

	if (raw_samples < 0) {
		printf("Error (%d) demuxing stream: %s\n", raw_samples, infileName);
		return -1;
	}

	dec = decode_raw_aac(raw_samples, outfile);
	
	if (dec < 0) {
		printf("Error (%d) decoding.\n", dec);
		return -1;
	}
	
	if (outfile)
		fclose(outfile);
	
	return 0;
}
