#!/bin/sh

PATH=$PATH:/usr/X11R6/bin

builddirs="ipod ipod-x11"

for dir in $builddirs; do
	mkdir -p $dir
	cd $dir
	lndir ../src
	cd ..
done
