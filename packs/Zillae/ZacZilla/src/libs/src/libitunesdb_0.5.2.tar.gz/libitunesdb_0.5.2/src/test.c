/*
 * Copyright (C) 2004 Jens Taprogge <jens.taprogge@post.rwth-aachen.de>
 *
 * See COPYING for details.
 */

#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include "itunesdb.h"
	
struct itdb_track *t2;
int tracks;

int track_cb_1(struct itdb_track *t, void *user) 
{
	if (t->playcount) {
/*		if (t->artist) {
			printf("%s: ", t->artist);
		}
		if (t->title) {
			printf("%s --- ", t->title);
		}

		printf(" (%i/%i); vol %i; rating: %i; pc: %i, lp: %s",
			t->trackno, t->notracks, t->voladj, t->rating,
			t->playcount, ctime(&t->lastplayed));
*/		t2 = t;
	}
	
	tracks++;
	return 0;
}


int plist_cb_1(struct itdb_plist *p, void *user) 
{
	int i;

	printf("New Plist type %i contains %i tracks.\n", p->type, p->notracks);
	for (i = 0; i < p->notracks; i++) {
		printf("%i, ", (p->ipodids)[i]);
	}
	printf("\n");
	return 0;
}


int notracks_cb_1(unsigned int notracks, void *user) 
{
	printf("DB contains %i tracks.\n", notracks);
	return 0;
}


int noplists_cb_1(unsigned int noplists, void *user) 
{
	printf("DB contains %i plists.\n", noplists);
	return 0;
}


int main(int argc, char *argv[]) 
{
	struct itdb_parsecont *pc = itdb_new_parsecont();
	struct timeval tv1, tv2, tvdiff;
	float diff;

	itdb_add_track_cb(pc, track_cb_1, NULL);
	itdb_add_plist_cb(pc, plist_cb_1, NULL);
	itdb_add_notracks_cb(pc, notracks_cb_1, NULL);
	itdb_add_noplists_cb(pc, noplists_cb_1, NULL);
	itdb_sel_parseentries(pc, ITDB_PARSE_ALL & ~ITDB_PARSE_PLAYLIST_MASTER);
	
	fprintf(stderr, "start parsing... \n");
	gettimeofday(&tv1, NULL);
	
	tracks = 0;
	if (itdb_parse_file(pc, "iTunesDB"))
		return 5;
	
	gettimeofday(&tv2, NULL);

	timersub(&tv2, &tv1, &tvdiff);
	diff = (float) tvdiff.tv_sec + (float) tvdiff.tv_usec / 1000.0 / 1000.0;

	printf("%i tracks parsed in %f seconds.\n", tracks, diff);
	
	itdb_upd_play(pc, t2->db_offset);
	itdb_set_rating(pc, t2->db_offset, 5);
	
	itdb_delete_parsecont(pc);
	printf("test end\n");
	return 0;
}
