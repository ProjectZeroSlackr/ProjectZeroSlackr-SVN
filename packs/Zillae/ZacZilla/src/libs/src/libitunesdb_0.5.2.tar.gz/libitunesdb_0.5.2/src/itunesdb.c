/*
 * Copyright (C) 2004 Jens Taprogge <jens.taprogge@post.rwth-aachen.de>
 *
 * See COPYING for details.
 */

#define PROFILE 1

#include "config.h"

#include <sys/types.h>
#include <sys/stat.h>
#ifdef HAVE_BYTESWAP_H
#include <byteswap.h>
#else
#ifdef __APPLE__
#include <machine/byte_order.h>
#define bswap_32(x) NXSwapInt(x)
#endif
#endif
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <netinet/in.h>

#include "itunesdb_private.h"
#include "ConvertUTF.h"
#include "config.h"


#define DEFAULTCACHESIZE	64*1024
#define SEEK_THRESH		128
#define BUFCHUNK		64


#ifdef PROFILE
#include <sys/times.h>

float tps;

static struct tms read_t1, read_t2;
static struct tms mhod_t1, mhod_t2;
static struct tms trackcb_t1, trackcb_t2;
static struct tms plistcb_t1, plistcb_t2;
static struct tms total_t1, total_t2;

unsigned long read_utime, read_stime;
unsigned long mhod_utime, mhod_stime;
unsigned long trackcb_utime, trackcb_stime;
unsigned long plistcb_utime, plistcb_stime;
unsigned long total_utime, total_stime;
#endif

static void init_parsecont(struct itdb_parsecont *pc) 
{
	memset(pc, 0, sizeof(struct itdb_parsecont));
	pc->parsesel = ITDB_PARSE_ALL;
	pc->track_parsesel = pc->parsesel & ~ITDB_PARSE_PLAYLIST_ANY;
	pc->fd = -1;
	pc->cache_minsize = DEFAULTCACHESIZE;
	
}


void itdb_track_free(struct itdb_track *t) 
{
	free(t->title);
	free(t->path); 
	free(t->album);
	free(t->artist);
	free(t->genre);
	free(t->fdesc);
	free(t->comment);
	free(t->composer);
	free(t);
}

struct itdb_track *itdb_track_dup(struct itdb_track *t)
{
	struct itdb_track *ret = (struct itdb_track *) 
		malloc(sizeof(struct itdb_track));

	memset(ret, 0, sizeof(struct itdb_track));

	if ((t->title) && (!(ret->title = strdup(t->title))))  
		goto fail;
	if ((t->album) && (!(ret->album = strdup(t->album))))  
		goto fail;
	if ((t->artist) && (!(ret->artist = strdup(t->artist)))) 
		goto fail;
	if ((t->genre) && (!(ret->genre = strdup(t->genre))))  
		goto fail;
	if ((t->fdesc) && (!(ret->fdesc = strdup(t->fdesc))))  
		goto fail;
	if ((t->comment) && (!(ret->comment = strdup(t->comment))))  
		goto fail;
	if ((t->composer) && (!(ret->composer = strdup(t->composer))))
		goto fail;

	ret->db_offset = t->db_offset;
	ret->filetype = t->filetype;
	ret->filesize = t->filesize;
	ret->lastmod = t->lastmod;
	ret->lastplayed = t->lastplayed;
	ret->rating = t->rating;
	ret->length = t->length;
	ret->year = t->year;
	ret->trackno = t->trackno;
	ret->notracks = t->notracks;
	ret->cdno = t->cdno;
	ret->nocds = t->nocds;
	ret->voladj = t->voladj;
	ret->playcount = t->playcount;

	return ret;
fail:
	itdb_track_free(ret);
	return NULL;

}


static inline int new_track(struct itdb_parsecont *pc) 
{
	if (!pc->track) {
		pc->track = (void *) malloc(sizeof(struct itdb_track));
		if (!pc->track) {
			fprintf(stderr, "new_itdb_track: can not alloc.\n");
			return -1;
		}
	}

	memset(pc->track, 0, sizeof(struct itdb_track));
	pc->track->db_offset = pc->record_start;
	
	pc->track_toparse = pc->track_parsesel;

	return 0;
}


inline int new_plist(struct itdb_parsecont *pc) 
{
	if (!pc->plist) {
		pc->plist = (void *) malloc(sizeof(struct itdb_plist));
		if (!pc->plist) {
			fprintf(stderr, "new_plist: can not alloc.\n");
			return -1;
		}
	}

	memset(pc->plist, 0, sizeof(struct itdb_plist));
	pc->plist->db_offset = pc->record_start;
	pc->plist_i = 0;
	
	return 0;
}


inline int track_done(struct itdb_parsecont *pc) 
{
#ifdef PROFILE
	int ret = 0;
	times(&trackcb_t1);
	if (pc->track_cb) ret = pc->track_cb(pc->track, pc->track_cb_userdata);
	times(&trackcb_t2);

	trackcb_utime += trackcb_t2.tms_utime - trackcb_t1.tms_utime;
	trackcb_stime += trackcb_t2.tms_stime - trackcb_t1.tms_stime;
	
	return ret;
#else
	if (pc->track_cb) return pc->track_cb(pc->track, pc->track_cb_userdata);
	return 0;
#endif
}


inline int plist_done(struct itdb_parsecont *pc) 
{
#ifdef PROFILE
	int ret = 0;
	times(&plistcb_t1);
	if (pc->plist_cb) ret = pc->plist_cb(pc->plist, pc->plist_cb_userdata);
	times(&plistcb_t2);

	plistcb_utime += plistcb_t2.tms_utime - plistcb_t1.tms_utime;
	plistcb_stime += plistcb_t2.tms_stime - plistcb_t1.tms_stime;
	
	return ret;
#else
	if (pc->plist_cb) return pc->plist_cb(pc->plist, pc->plist_cb_userdata);
	return 0;
#endif
}


inline int notracks_done(struct itdb_parsecont *pc)
{
	if (pc->notracks_cb) 
		return pc->notracks_cb(pc->notracks, pc->notracks_cb_userdata);
	return 0;
}


inline int noplists_done(struct itdb_parsecont *pc)
{
	if (pc->noplists_cb) 
		return pc->noplists_cb(pc->noplists, pc->noplists_cb_userdata);
	return 0;
}


static void move_cache(struct itdb_parsecont *pc, size_t preserve)
{
	off_t off;
	
	if (preserve) {
		off = pc->cache_pos - (pc->cache_end - preserve);
		
		if (preserve * 2 < pc->cache.size) {
			memcpy(pc->cache.data, pc->cache_end - preserve,
					preserve);
		} else {
			memmove(pc->cache.data, pc->cache_end - preserve,
					preserve);
		}

		pc->cache_pos = pc->cache.data + off;
		pc->cache_end = pc->cache.data + preserve;
	} else {
		pc->cache_pos = pc->cache.data;
		pc->cache_end = pc->cache.data;
	}
}


static int alloc_cache(struct itdb_parsecont *pc, size_t newsize, 
		size_t preserve)
{
	char *new_buf;
	off_t off;

	if (newsize < pc->cache_minsize) newsize = pc->cache_minsize;
	newsize += (BUFCHUNK - (newsize % BUFCHUNK)) % BUFCHUNK;
	
	new_buf = (void *) malloc(newsize);
	if (!new_buf) return pc->cache.size;

	if (pc->cache.data) {
		off = pc->cache_pos - (pc->cache_end - preserve);
		if (preserve)
			memcpy(new_buf, pc->cache_end - preserve, preserve);
		free(pc->cache.data);
	} else {
		off = 0;
	}

	pc->cache.data = new_buf;
	pc->cache.size = newsize;
	pc->cache_pos = pc->cache.data + off;
	pc->cache_end = pc->cache.data + preserve;
	return newsize;
}


static size_t alloc_buf(struct buffer *buf, size_t newsize) 
{
	char *new_buf;
	
	newsize += (BUFCHUNK - (newsize % BUFCHUNK)) % BUFCHUNK;
	new_buf = (void *) realloc(buf->data, newsize);
	if (!new_buf) return buf->size;
	
	buf->size = newsize;
	buf->data = new_buf;
	return newsize;
}


static int check_cachesize(struct itdb_parsecont *pc, unsigned int size) 
{
	if (pc->cache.data + pc->cache.size - pc->buf < size) {
		/* out of cache */
		if (size > pc->cache.size) {
			/* cache is actually to small */
			if (alloc_cache(pc, size, 0) < size) {
				fprintf(stderr, "Can not allocate sufficient "
						"amount of memory.\n");
				return -1;
			}
		} else {
			move_cache(pc, 0);
		}
	}
	
	return 0;
}


/*
 * ipod to host long
 */

inline void set_uint32_t (uint32_t *dst, uint32_t i)
{
#ifdef WORDS_BIGENDIAN
	*dst = i;
#else
	if (((int) dst & 3) == 0) {
		*dst = i;
	} else {
		uint16_t *p16 = (uint16_t *) dst;
		p16[0] = i & 0xffff;
		p16[1] = (i >> 16) & 0xffff;
	}
#endif
}

inline uint32_t itohl(uint32_t *p) 
{
#ifdef WORDS_BIGENDIAN
	return bswap_32(*p);
#else
	if (((int) p & 3) == 0) {
		return *p;
	} else {
		uint16_t *p16 = (uint16_t *) p;
		return ((p16[1] << 16) | p16[0]);
	}
#endif
}


inline uint32_t htoil(uint32_t *p) 
{
	return itohl(p);
}

inline ssize_t profile_read(int fd, void *buf, size_t count) 
{
#ifdef PROFILE
	ssize_t ret;
	times(&read_t1);
	ret = read(fd, buf, count);
	times(&read_t2);

	read_utime += read_t2.tms_utime - read_t1.tms_utime;
	read_stime += read_t2.tms_stime - read_t1.tms_stime;
	return ret;
#else
	return read(fd, buf, count);
#endif
}


static size_t fill_cache(struct itdb_parsecont *pc, size_t num, size_t preserve)
{
	int ret;
	int rbytes = 0;

	/* check buffer size */
	if (num + preserve > pc->cache.size) {
		/* buffer is to small */
		alloc_cache(pc, num + preserve, preserve);
	} else if (preserve) {
		move_cache(pc, preserve);
	} else {
		pc->cache_pos = pc->cache.data;
		pc->cache_end = pc->cache.data;
	}

	num = pc->cache.size - preserve;

	while (rbytes < num) {
		if ((ret = profile_read(pc->fd, pc->cache_end, num - rbytes))
				<= 0) {
			if (!ret) return rbytes;
			return ret;
		}
		rbytes += ret;
		pc->file_pos += ret;
		pc->cache_end += ret;
	}
	return rbytes;
}

static int seek_to_cp(struct itdb_parsecont *pc)
{
	pc->file_pos = lseek(pc->fd, pc->cache_pos - pc->cache_end, SEEK_CUR);
	
	pc->cache_pos = pc->cache.data;
	pc->cache_end = pc->cache.data;
	if (pc->file_pos < 0) perror("seek failed");
	return pc->file_pos;
}

/*
 * returns number of bytes read in total or -1 on error.
 */

static size_t readbytes(struct itdb_parsecont *pc, int num, 
		off_t off) 
{
	int ret;
	int extra;

	if (num < 0) return 0;

	if (pc->cache_pos < pc->cache.data) {
		/* data starts before cache */
		if (seek_to_cp(pc) < 0) return 0;
	} else 	if (pc->cache_pos - pc->cache_end > SEEK_THRESH) {
		/* lots of unneded bytes - skip those */
		if (seek_to_cp(pc) < 0) return 0;
	}

	if (pc->cache_end - pc->cache_pos < num) {
		/* data is beyond cache. */ 
		if (pc->cache_pos > pc->cache_end) {
			/* there are some unneeded bytes to be read. */
			
			extra = pc->cache_pos - pc->cache_end;
			
			ret = fill_cache(pc, num + extra, 0);
			if (ret < num + extra) num = ret - extra;
			
			pc->cache_pos += extra;
		} else {
			ret = fill_cache(pc, num, pc->cache_end -
					pc->cache_pos);
			if (ret < num) num = ret;
		}
	}

	pc->buf = pc->cache_pos - off;
	pc->cache_pos += num;
	pc->buf_pos += num;
	return num;
}


static off_t seekpos(struct itdb_parsecont *pc, off_t off) 
{
	int offfile = off - pc->file_pos;
	char *new_cp;
	
	new_cp = pc->cache_end + offfile;

	pc->buf_pos += new_cp - pc->cache_pos;
	pc->cache_pos = new_cp;

	return off;
}


inline off_t skipbytes(struct itdb_parsecont *pc, unsigned int num) 
{
	pc->cache_pos += num;
	pc->buf_pos += num;
	
	return num;
}

/*
 * returns number of bytes read in total or -1 on error.
 * FIXME: This could be optimized by reducing the seeking.
 */

static int writebytes(struct itdb_parsecont *pc, unsigned int num, 
		unsigned int off)
{
	int ret;
	int wbytes = 0;
	off_t fp;
	
	fp = lseek(pc->fd, pc->cache_pos - pc->cache_end, SEEK_CUR);
	if (fp < 0) return 0;

	while (wbytes < num) {
		if ((ret = write(pc->fd, pc->buf + off + wbytes, 
						num - wbytes)) <= 0)
		{
			if (!ret) return wbytes;
			return ret;
		}
		wbytes += ret;
		pc->buf_pos += ret;
		pc->cache_pos += ret;
	}
	lseek(pc->fd, pc->file_pos, SEEK_SET);
	
	return wbytes;
}


/* 
 * Returns -2 the current position is exactly at the ond of the file;
 * -1 on error.
 */

inline int read_header(struct itdb_parsecont *pc) 
{
	int ret; 

	if ((ret = readbytes(pc, 8, 0)) != 8) {
		if (ret == 0)
			return -2;
		return -1;
	}

	
	pc->type = itohl(&((uint32_t *) pc->buf)[OFFSET_TYPE]);
	pc->size = itohl(&((uint32_t *) pc->buf)[OFFSET_SIZE]);
	
	return 0;
}


inline int read_data(struct itdb_parsecont *pc) 
{
	int ret;

	/* end of file should not occur now */
	if ((ret = readbytes(pc, pc->size - 8, 8)) < pc->size - 8) return -1;

	return 0;
}


inline int parse_mhbd(struct itdb_parsecont *pc) 
{
	if (pc->record_start) 
		fprintf(stderr, "MHBD not at beginning of file\n");

	return 0;
}


inline int parse_mhip(struct itdb_parsecont *pc) 
{
	--pc->mhips;

	pc->mhods = itohl(&((uint32_t *) pc->buf)[OFFSET_MHIP_NOMHODS]);
	((uint32_t *) pc->plistbuf.data)[pc->plist_i++] = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIP_IPODID]);
	return 0;
}


static int parse_mhit(struct itdb_parsecont *pc) 
{
	new_track(pc);
	pc->mhods = itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_NOMHODS]);
	pc->track->ipodid = itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_IPODID]);

	pc->track->trackno = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_TRACKNO]);
	
	if (!(pc->parsesel && ITDB_PARSE_DETAILS)) return 0;
	
	pc->track->notracks = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_NOTRACKS]);
	pc->track->year = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_YEAR]);
	pc->track->voladj = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_VOLADJ]);
	pc->track->playcount = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_PLAYCOUNT]);
	pc->track->lastplayed = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_LASTPLAYED]);
	/* convert to UNIX Epoch based time */
	if (pc->track->lastplayed) pc->track->lastplayed += EPOCH_MAC2UNIX;
	pc->track->cdno = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_CDNO]);
	pc->track->nocds = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_NOCDS]);

	pc->track->rating = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_RATINGANDTYPE]) 
		>> 24;
	pc->track->filetype = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_RATINGANDTYPE]) 
		& 0xffffff;
	pc->track->lastmod = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_LASTMOD]);
	/* convert to UNIX Epoch based time */
	if (pc->track->lastmod) pc->track->lastmod += EPOCH_MAC2UNIX;
	pc->track->filesize = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_FILESIZE]);
	pc->track->length = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHIT_LENGTH]);
	
	return 0;
}


inline int parse_mhlt(struct itdb_parsecont *pc) 
{
	pc->notracks = itohl(&((uint32_t *) pc->buf)[OFFSET_MHLT_NOTRACKS]);
	pc->mhods = 0;
	return 0;
}


inline int parse_mhlp(struct itdb_parsecont *pc) 
{
	pc->noplists = itohl(&((uint32_t *) pc->buf)[OFFSET_MHLP_NOPLISTS]);
	pc->mhods = 0;
	return 0;
}


inline int parse_mhsd(struct itdb_parsecont *pc) 
{
	pc->section_next = pc->record_start + 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHSD_SIZE]);
	pc->section_type = itohl(&((uint32_t *) pc->buf)[OFFSET_MHSD_TYPE]);
	switch (pc->section_type) {
		case MHSD_TYPE_TRACK:
			pc->tracksec_db_offset = pc->record_start;
			break;
		case MHSD_TYPE_PLAYLIST:
			pc->plistsec_db_offset = pc->record_start;
			break;
		default:
			fprintf(stderr, "Unknown section: %i.\n",
					pc->section_type);
			break;
	}
	return 0;
}


inline int parse_mhyp(struct itdb_parsecont *pc) 
{
	new_plist(pc);
	pc->plist_next = pc->record_start +
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHYP_SIZE]);
	pc->mhods = itohl(&((uint32_t *) pc->buf)[OFFSET_MHYP_NOMHODS]);
	pc->plist->notracks = 
		itohl(&((uint32_t *) pc->buf)[OFFSET_MHYP_NOTRACKS]);
	pc->mhips = pc->plist->notracks;
	pc->plist->type = itohl(&((uint32_t *) pc->buf)[OFFSET_MHYP_PLTYPE]);
	if (pc->plistbuf.size < 4 * pc->plist->notracks) 
		alloc_buf(&pc->plistbuf, 4 * pc->plist->notracks);
	pc->plist->ipodids = (uint32_t *) pc->plistbuf.data;
	return 0;
}


inline char *new_utf8_from_utf16(struct buffer *buf, char *start, 
		unsigned int len) 
{
	const UTF16	*sourceStart = (UTF16*) start;
	UTF16		*sourceEnd;
	UTF8		*targetStart, *targetEnd;
	size_t		 size;
	
	/* A utf8 character can be at most 4 bytes long while len is the number
	 * of utf16 bytes. */
	if (buf->size < len * 2 + 1) alloc_buf(buf, len * 2 + 1);

	sourceStart = (UTF16*) start;
	sourceEnd = (UTF16*) start + len/2;
	targetStart = buf->data;
	targetEnd = buf->data + buf->size; 
	if (ConvertUTF16toUTF8(&sourceStart, sourceEnd, 
			&targetStart, targetEnd, strictConversion)
			!= conversionOK) {
		fprintf(stderr, "UTF16 to UTF8 conversion failed.\n");
		return NULL;
	}
	size = (char *) targetStart - buf->data;
	buf->data[size] = '\0';
	return buf->data;
}


inline void set_record_mhod_mhit(struct itdb_parsecont *pc, uint32_t id, 
		char *data)
{
	int i;

	switch (id) {
		case MHOD_ID_TITLE:
			pc->track->title = data;
			pc->track_toparse &= ~ITDB_PARSE_TITLE;
			break;
		case MHOD_ID_PATH:
			/* convert to unix path */
			for (i = 1; data[i - 1]; i ++)
				data[i - 1] = (data[i] == ':') ? '/' : data[i];
			pc->track->path = data;
			pc->track_toparse &= ~ITDB_PARSE_PATH;
			break;
		case MHOD_ID_ALBUM:
			pc->track->album = data;
			pc->track_toparse &= ~ITDB_PARSE_ALBUM;
			break;
		case MHOD_ID_ARTIST:
			pc->track->artist = data;
			pc->track_toparse &= ~ITDB_PARSE_ARTIST;
			break;
		case MHOD_ID_GENRE:
			pc->track->genre = data;
			pc->track_toparse &= ~ITDB_PARSE_GENRE;
			break;
		case MHOD_ID_FDESC:
			pc->track->fdesc = data;
			break;
		case MHOD_ID_COMMENT:
			pc->track->comment = data;
			break;
		case MHOD_ID_COMPOSER:
			pc->track->composer = data;
			pc->track_toparse &= ~ITDB_PARSE_COMPOSER;
			break;
		default:
			break;
	}
}


inline void set_record_mhod_mhyp(struct itdb_parsecont *pc, uint32_t id, 
		char *data)
{
	switch (id) {
		case MHOD_ID_TITLE:
			pc->plist->title = data;
			break;
		default:
			fprintf(stderr, "Unhandled id %i mode %x: %s.\n",
					id, pc->mhodmode, data);
			break;
	}
}


static int sparse_mhod(struct itdb_parsecont *pc) 
{
	uint32_t 	 id;
	unsigned int	 size;
	unsigned int	 entrylen;
	struct buffer	*tbuf;
	
	pc->mhods--;
	
	if (pc->size < (OFFSET_MHOD_SIZE + 1) * 4) {
		fprintf(stderr, "parse_mhod: size to small.\n");
		return -1;
	}

	size = itohl(&((uint32_t *) pc->buf)[OFFSET_MHOD_SIZE]);

	/* XXX Never been able to find anything useful in these... */
	if (pc->mhodmode == TYPE_MHIP_ID) {
		if (skipbytes(pc, size - pc->size) != size - pc->size)
			return -1;
		return 0;
	}
	
	if ((pc->mhodmode == TYPE_MHIT_ID) && (!pc->track_toparse)) {
		if (skipbytes(pc, size - pc->size) != size - pc->size)
			return -1;
		return 0;
	}
	

	if (readbytes(pc, size - pc->size, pc->size) != size - pc->size) 
		return -1;

	entrylen = itohl(&((uint32_t *) 
				pc->buf)[OFFSET_MHOD_ENTLEN]);

	if (size < 40 + entrylen) {
		fprintf(stderr, "mhod to small\n");
	}

	id = (itohl(&((uint32_t *) pc->buf)[OFFSET_MHOD_TYPE]));
	
	/* not interested in those. They are for iTunes use only */
	if (id == MHOD_ID_PLAYLIST) return 0;
	
	switch (pc->mhodmode) {
		case TYPE_MHIT_ID:
			if (!(MHOD_TO_PARSE[id] & pc->track_toparse)) return 0;
			break;
	}
	
	switch (id) {
		case MHOD_ID_TITLE:
			tbuf = &pc->titlebuf;
			break;
		case MHOD_ID_PATH:
			tbuf = &pc->pathbuf;
			break;
		case MHOD_ID_ALBUM:
			tbuf = &pc->albumbuf;
			break;
		case MHOD_ID_ARTIST:
			tbuf = &pc->artistbuf;
			break;
		case MHOD_ID_GENRE:
			tbuf = &pc->genrebuf;
			break;
		case MHOD_ID_FDESC:
			tbuf = &pc->fdescbuf;
			break;
		case MHOD_ID_COMMENT:
			tbuf = &pc->commentbuf;
			break;
		case MHOD_ID_COMPOSER:
			tbuf = &pc->composerbuf;
			break;
		case MHOD_ID_PLAYLIST:
			/* Not know the significance of these records */
			return 0;
			break;
		default:
			tbuf = &pc->backupbuf;
			break;
	}

	if (!(new_utf8_from_utf16(tbuf, pc->buf + OFFSET_MHOD_DATA 
					* 4, entrylen))) 
		return -1;

	switch (pc->mhodmode) {
		case TYPE_MHIT_ID:
			set_record_mhod_mhit(pc, id, tbuf->data);
			break;
		case TYPE_MHYP_ID:
			set_record_mhod_mhyp(pc, id, tbuf->data);
			break;
		default:
			fprintf(stderr, "Unhandled mhodmode %x id %i: %s.\n",
					pc->mhodmode, id, tbuf->data);
			break;
	}

	return 0;
}


inline int parse_mhod(struct itdb_parsecont *pc) 
{
#ifdef PROFILE
	int ret;
	times(&mhod_t1);
	ret = sparse_mhod(pc);
	times(&mhod_t2);

	mhod_utime += mhod_t2.tms_utime - mhod_t1.tms_utime;
	mhod_stime += mhod_t2.tms_stime - mhod_t1.tms_stime;
	return ret;
#else
	return sparse_mhod(pc);
#endif
}



static int seek_mhit(struct itdb_parsecont *pc, unsigned int offset)
{
	int ret;
	
	if (seekpos(pc, offset) != offset) return -1;
	
	pc->record_start = offset;
	
	if ((ret = read_header(pc))) return ret;

	if (pc->type != TYPE_MHIT_ID) {
		fprintf(stderr, "Offset does not point to mhit record.\n");
		return -1;
	}
	pc->mhodmode = pc->type;

	return 0;
}


/* 
 * Expects current filepos to be right after the header of the record.
 * (such as for example after calling read_header or seek_mhit 
 */
inline int seek_entry(struct itdb_parsecont *pc, int entryoffset)
{
	int byteoffset = (entryoffset - OFFSET_SIZE - 1) * 4;
	
	if (skipbytes(pc, byteoffset) != byteoffset) return -1;
	
	return 0;
}


/* 
 * Expects current filepos to be right after the entry.
 */
inline int seek_back_entry(struct itdb_parsecont *pc, int entryoffset)
{
	int byteoffset = (entryoffset - OFFSET_SIZE - 1 + 1) * 4;
	
	if (skipbytes(pc, byteoffset) != byteoffset) return -1;

	return 0;
}


/* 
 * Expects current filepos to be right after the header of the record.
 * (such as for example after calling read_header or seek_mhit 
 */
static int read_entry(struct itdb_parsecont *pc, unsigned int entryoffset,
		uint32_t *value)
{
	if (seek_entry(pc, entryoffset)) return -1;
	
	if (readbytes(pc, 4, entryoffset * 4) != 4) return -1;
	pc->buf_pos += 4;
	
	*value = itohl(&((uint32_t *) pc->buf)[entryoffset]);
	
	if (seek_back_entry(pc, entryoffset)) return -1;

	return 0;
}


/* 
 * Expects current filepos to be right after the header of the record.
 * (such as for example after calling read_header or seek_mhit 
 */
static int write_entry(struct itdb_parsecont *pc, unsigned int entryoffset,
		uint32_t value)
{
	if (seek_entry(pc, entryoffset)) return -1;
	
	if (check_cachesize(pc, entryoffset + 4)) return -1;
	
	set_uint32_t(&(((uint32_t *) pc->buf)[entryoffset]), htoil(&value));
	
	if (writebytes(pc, 4, entryoffset * 4) != 4) return -1;
	
	if (seek_back_entry(pc, entryoffset)) return -1;

	return 0;
}


inline void check_done(struct itdb_parsecont *pc)
{
	switch (pc->mhodmode) {
		case TYPE_MHIP_ID:
		case TYPE_MHYP_ID:
			if (!pc->mhips) plist_done(pc);
			break;
		case TYPE_MHIT_ID:
			track_done(pc);
			break;
		case TYPE_MHLT_ID:
			notracks_done(pc);
			break;
		case TYPE_MHLP_ID:
			noplists_done(pc);
			break;
		case TYPE_MHSD_ID:
			break;
		default:
			break;
	}
}


inline void check_sec_skip(struct itdb_parsecont *pc)
{
	switch (pc->section_type) {
		case MHSD_TYPE_TRACK:
			if ((!(pc->parsesel & ITDB_PARSE_TRACK_ANY)) |
					(!pc->track_cb))
				seekpos(pc, pc->section_next);
			break;
		case MHSD_TYPE_PLAYLIST:
			if ((!(pc->parsesel & ITDB_PARSE_PLAYLIST_ANY)) |
					(!pc->plist_cb))
				seekpos(pc, pc->section_next);
			break;
		default:
			fprintf(stderr, "check_sec_skip: unknown section type");
			break;
	}
}


inline void check_plist_skip(struct itdb_parsecont *pc)
{
	switch (pc->plist->type) {
		case MHYP_TYPE_MASTER:
			if (!(pc->parsesel & ITDB_PARSE_PLAYLIST_MASTER))
				seekpos(pc, pc->plist_next);
			break;
			if (!pc->parsesel & ITDB_PARSE_TRACK_ANY) 
				seekpos(pc, pc->section_next);
			break;
		case MHYP_TYPE_NORMAL:
			if (!(pc->parsesel & ITDB_PARSE_PLAYLIST_NORMAL))
				seekpos(pc, pc->plist_next);
			break;
		default:
			fprintf(stderr, "check_plist_skip: unknown plist "
					"type\n");
			break;
	}
}

	
/* 
 * returns -2 on end of file, -1 on error 
 */

inline int parse_record(struct itdb_parsecont *pc) 
{
	int ret; 
	
	pc->record_start = pc->buf_pos;
	if ((ret = read_header(pc))) return ret;
	if (read_data(pc)) return -1;
	if (pc->type != TYPE_MHOD_ID) pc->mhodmode = pc->type;
	
	switch (pc->type) {
		case TYPE_MHBD_ID: 
			parse_mhbd(pc);
			break;
		case TYPE_MHIP_ID: 
			parse_mhip(pc);
			break;
		case TYPE_MHIT_ID: 
			parse_mhit(pc);
			break;
		case TYPE_MHLT_ID:
			parse_mhlt(pc);
			break;
		case TYPE_MHLP_ID:
			parse_mhlp(pc);
			break;
		case TYPE_MHSD_ID:
			parse_mhsd(pc);
			check_sec_skip(pc);
			break;
		case TYPE_MHOD_ID:
			parse_mhod(pc);
			break;
		case TYPE_MHYP_ID:
			parse_mhyp(pc);
			check_plist_skip(pc);
			break;
		default:
			fprintf(stderr, "parse_record: unknown type: %x\n", 
					pc->type);
			break;
	}
	
	if (!pc->mhods) check_done(pc);

	return 0;
}


struct itdb_parsecont *itdb_new_parsecont() 
{
	struct itdb_parsecont *pc;
	pc = (void *) malloc(sizeof(struct itdb_parsecont));
	if (!pc) return pc;
	
	init_parsecont(pc);

	return pc;
}


void itdb_delete_parsecont(struct itdb_parsecont *pc) 
{
	if (pc->fd >= 0) close(pc->fd);
	free(pc->titlebuf.data);
	free(pc->pathbuf.data);
	free(pc->albumbuf.data);
	free(pc->artistbuf.data);
	free(pc->genrebuf.data);
	free(pc->fdescbuf.data);
	free(pc->commentbuf.data);
	free(pc->composerbuf.data);
	free(pc->cache.data);
	free(pc);
}


void itdb_add_track_cb(struct itdb_parsecont *pc, 
		itdb_track_callback track_cb, void *userdata) 
{
	pc->track_cb = track_cb;
	pc->track_cb_userdata = userdata;
}


void itdb_add_plist_cb(struct itdb_parsecont *pc, 
		itdb_plist_callback track_cb,
		void *userdata) 
{
	pc->plist_cb = track_cb;
	pc->plist_cb_userdata = userdata;
}


void itdb_add_notracks_cb(struct itdb_parsecont *pc, 
		itdb_notracks_callback notracks_cb, void *userdata) 
{
	pc->notracks_cb = notracks_cb;
	pc->notracks_cb_userdata = userdata;
}


void itdb_add_noplists_cb(struct itdb_parsecont *pc, 
		itdb_noplists_callback noplists_cb, void *userdata) 
{
	pc->noplists_cb = noplists_cb;
	pc->noplists_cb_userdata = userdata;
}


#ifdef PROFILE
void printtimes(long utime, long stime, char *title)
{
	float usecs, ssecs;
	usecs = (float) utime / tps;
	ssecs = (float) stime / tps;
	fprintf(stderr, "%s user time: %f, sys time %f\n", title, usecs, ssecs);
}
#endif

int itdb_parse_file(struct itdb_parsecont *pc, char *filename) 
{
	int ret;

#ifdef PROFILE
	read_utime = 0; read_stime = 0;
	mhod_utime = 0; mhod_stime = 0;
	trackcb_utime = 0; trackcb_stime = 0;
	plistcb_utime = 0; plistcb_stime = 0;
	total_utime = 0; total_stime = 0;
	tps = (float) sysconf(_SC_CLK_TCK);

	times(&total_t1);
#endif

	pc->fd = open(filename, O_RDWR);
	if (pc->fd == -1) {
		/* drop back to read only mode */
		pc->fd = open(filename, O_RDONLY);
		if (pc->fd == -1) {
			perror("Cant open");
			return -1;
		}
	}
	pc->buf_pos = 0;

	do {} while (!(ret = parse_record(pc)));

#ifdef PROFILE
	times(&total_t2);
	total_utime += total_t2.tms_utime - total_t1.tms_utime;
	total_stime += total_t2.tms_stime - total_t1.tms_stime;
	
	printtimes(read_utime, read_stime, "READ");
	printtimes(mhod_utime, mhod_stime, "MHOD");
	printtimes(trackcb_utime, trackcb_stime, "TRACK_CB");
	printtimes(plistcb_utime, plistcb_stime, "PLIST_CB");
	printtimes(total_utime, total_stime, "TOTAL");
#endif
	
	if (ret != -2)
		return -1;

	return 0;
}


int itdb_set_playcount(struct itdb_parsecont *pc, unsigned int db_offset, 
		unsigned short int pcount)
{
	int ret;

	if ((ret = seek_mhit(pc, db_offset))) return ret;
	
	if ((ret = write_entry(pc, OFFSET_MHIT_PLAYCOUNT, pcount))) return ret;

	return 0;
}


int itdb_set_lastplayed(struct itdb_parsecont *pc, unsigned int db_offset, 
		time_t lp)
{
	int ret;

	if ((ret = seek_mhit(pc, db_offset))) return ret;
	
	if ((ret = write_entry(pc, OFFSET_MHIT_LASTPLAYED, lp))) return ret;

	return 0;
}


int itdb_upd_play(struct itdb_parsecont *pc, unsigned int db_offset)
{
	int ret;
	uint32_t pcount;

	if ((ret = seek_mhit(pc, db_offset))) return ret;
	
	if ((ret = read_entry(pc, OFFSET_MHIT_PLAYCOUNT, &pcount))) 
		return ret;
	if ((ret = write_entry(pc, OFFSET_MHIT_PLAYCOUNT, pcount + 1))) 
		return ret;
	
	if ((ret = write_entry(pc, OFFSET_MHIT_LASTPLAYED, 
					time(NULL) - EPOCH_MAC2UNIX))) 
		return ret;

	return 0;
}


int itdb_set_rating(struct itdb_parsecont *pc, unsigned int db_offset, 
		unsigned short int rating)
{
	int ret;
	uint32_t rt;

	if ((ret = seek_mhit(pc, db_offset))) return ret;

	if (rating > 0xff) {
		fprintf(stderr, "Rating out of range.\n");
		return -1;
	}
	
	if ((ret = read_entry(pc, OFFSET_MHIT_RATINGANDTYPE, &rt))) return ret;
	if ((ret = write_entry(pc, OFFSET_MHIT_RATINGANDTYPE, 
					(rating << 24) | (rt & 0xffffff)))) 
		return ret;

	return 0;
}


struct itdb_track *itdb_read_track(struct itdb_parsecont *pc, unsigned int
		db_offset)
{
	struct itdb_track *ret;
	
	if (seek_mhit(pc, db_offset)) return NULL;
	if (read_data(pc)) return NULL;

	parse_mhit(pc);

	if (!pc->track) return NULL;
	ret = pc->track;

	do {
		if ((read_header(pc)) || (read_data(pc))) return NULL;
	
		switch (pc->type) {
			case TYPE_MHIP_ID: 
				parse_mhip(pc);
				break;
			case TYPE_MHOD_ID:
				parse_mhod(pc);
				if (!pc->mhods) {
					pc->track = NULL;
					return ret;
				}
				break;
			default:
				break;
		}
	} while (pc->type != TYPE_MHIT_ID);
	
	pc->track = NULL;
	return ret;
}


void itdb_sel_parseentries(struct itdb_parsecont *pc, unsigned int entries)
{
	pc->parsesel = entries;
	pc->track_parsesel = entries & ~ITDB_PARSE_PLAYLIST_ANY;
}


void itdb_set_cachesize(struct itdb_parsecont *pc, size_t size)
{
	pc->cache_minsize = size;
	if (pc->cache.data) alloc_cache(pc, size, 0);
}
