/*
 * Copyright (C) 2004 Jens Taprogge <jens.taprogge@post.rwth-aachen.de>
 *
 * See COPYING for details.
 */

#ifndef _ITUNESDB_PRIVATE
#define _ITUNESDB_PRIVATE

#include "itunesdb.h"

#define TYPE_MHIP_ID 0x7069686d /* ascii "mhip" - reverse byte order */
#define TYPE_MHIT_ID 0x7469686d /* ascii "mhit" - reverse byte order */
#define TYPE_MHLP_ID 0x706c686d /* ascii "mhlp" - reverse byte order */
#define TYPE_MHLT_ID 0x746c686d /* ascii "mhlt" - reverse byte order */
#define TYPE_MHOD_ID 0x646f686d /* ascii "mhod" - reverse byte orfer */
#define TYPE_MHBD_ID 0x6462686d /* ascii "mhbd" - reverse byte orfer */
#define TYPE_MHSD_ID 0x6473686d /* ascii "mhsd" - reverse byte orfer */
#define TYPE_MHYP_ID 0x7079686d /* ascii "mhyp" - reverse byte order */

#define EPOCH_MAC2UNIX (-2082844800)

/* header */
enum {
	OFFSET_TYPE = 0,
	OFFSET_SIZE
};


/* mhip */
enum {
	OFFSET_MHIP_1 = OFFSET_SIZE + 1, /* 8 */
	OFFSET_MHIP_NOMHODS,
	OFFSET_MHIP_3,
	OFFSET_MHIP_4,
	OFFSET_MHIP_IPODID
};


/* mhit */
enum {
	OFFSET_MHIT_1 = OFFSET_SIZE + 1, /* 8 */
	OFFSET_MHIT_NOMHODS,
	OFFSET_MHIT_IPODID,
	OFFSET_MHIT_4,
	OFFSET_MHIT_5,
	OFFSET_MHIT_RATINGANDTYPE, /* 28 */
	OFFSET_MHIT_LASTMOD,
	OFFSET_MHIT_FILESIZE,
	OFFSET_MHIT_LENGTH, /* 40 */
	OFFSET_MHIT_TRACKNO,
	OFFSET_MHIT_NOTRACKS,
	OFFSET_MHIT_YEAR,
	OFFSET_MHIT_BITRATE,
	OFFSET_MHIT_SAMPLERATE,
	OFFSET_MHIT_VOLADJ,
	OFFSET_MHIT_17,
	OFFSET_MHIT_18,
	OFFSET_MHIT_19,
	OFFSET_MHIT_PLAYCOUNT,
	OFFSET_MHIT_21,
	OFFSET_MHIT_LASTPLAYED,
	OFFSET_MHIT_CDNO,
	OFFSET_MHIT_NOCDS,
};

/* mhlp */
enum {
	OFFSET_MHLP_NOPLISTS = OFFSET_SIZE + 1 /* 8 */
};


/* mhlt */
enum {
	OFFSET_MHLT_NOTRACKS = OFFSET_SIZE + 1 /* 8 */
};


/* mhod */
enum {
	OFFSET_MHOD_SIZE = OFFSET_SIZE + 1,
	OFFSET_MHOD_TYPE,
	OFFSET_MHOD_ENTLEN = 7,
	OFFSET_MHOD_DATA = 10
};


enum {
	MHOD_ID_TITLE = 1,
	MHOD_ID_PATH,
	MHOD_ID_ALBUM,
	MHOD_ID_ARTIST,
	MHOD_ID_GENRE,
	MHOD_ID_FDESC,
	MHOD_ID_7,
	MHOD_ID_COMMENT,
	MHOD_ID_9,
	MHOD_ID_10,
	MHOD_ID_11,
	MHOD_ID_COMPOSER,
	MHOD_ID_TRACK_MAX = MHOD_ID_COMPOSER,
	MHOD_ID_PLAYLIST = 100
};


/* mhsd */
enum {
	OFFSET_MHSD_SIZE = OFFSET_SIZE + 1, /* 8 */
	OFFSET_MHSD_TYPE,
	OFFSET_MHSD_3,
	OFFSET_MHSD_4,
};

enum {
	MHSD_TYPE_TRACK = 1,
	MHSD_TYPE_PLAYLIST
};


/* mhyp */
enum {
	OFFSET_MHYP_SIZE = OFFSET_SIZE + 1, /* 8 */
	OFFSET_MHYP_NOMHODS,
	OFFSET_MHYP_NOTRACKS,
	OFFSET_MHYP_PLTYPE
};

enum {
	MHYP_TYPE_NORMAL = 0,
	MHYP_TYPE_MASTER 
};



struct buffer {
	char			*data;
	size_t			 size;
};

struct itdb_parsecont {
	char	 		*buf;
	struct buffer 		 cache;
	size_t			 cache_minsize;
	char	 		*cache_pos;
	char	 		*cache_end;
	off_t	 		 file_pos;
	struct buffer		 titlebuf;
	struct buffer		 pathbuf;
	struct buffer		 albumbuf;
	struct buffer		 artistbuf;
	struct buffer		 genrebuf;
	struct buffer		 fdescbuf;
	struct buffer		 commentbuf;
	struct buffer		 composerbuf;
	struct buffer		 plistbuf;
	struct buffer		 backupbuf;
	unsigned int 		 buf_pos;
	int			 fd;
	uint32_t		 type;
	unsigned int 		 size;
	unsigned int 		 record_start;
	uint32_t		 mhodmode;
	unsigned int 		 mhods;
	unsigned int 		 mhips;
	unsigned int 		 notracks;
	unsigned int 		 noplists;
	struct itdb_track	*track;
	struct itdb_plist	*plist;
	uint32_t		 plist_i;
	unsigned int		 plist_next;
	itdb_track_callback	 track_cb;
	void			*track_cb_userdata;
	itdb_plist_callback	 plist_cb;
	void			*plist_cb_userdata;
	itdb_notracks_callback	 notracks_cb;
	void			*notracks_cb_userdata;
	itdb_noplists_callback	 noplists_cb;
	void			*noplists_cb_userdata;
	unsigned int		 parsesel;
	unsigned int		 track_parsesel;
	unsigned int		 track_toparse;
	unsigned int		 section_type;
	unsigned int		 section_next;
	unsigned int		 tracksec_db_offset;
	unsigned int		 plistsec_db_offset;
};


static int MHOD_TO_PARSE[MHOD_ID_TRACK_MAX + 1] =
{
	ITDB_PARSE_UNKNOWN,
	ITDB_PARSE_TITLE,
	ITDB_PARSE_PATH,
	ITDB_PARSE_ALBUM,
	ITDB_PARSE_ARTIST,
	ITDB_PARSE_GENRE,
	ITDB_PARSE_DETAILS,
	ITDB_PARSE_UNKNOWN,
	ITDB_PARSE_DETAILS,
	ITDB_PARSE_UNKNOWN,
	ITDB_PARSE_UNKNOWN,
	ITDB_PARSE_UNKNOWN,
	ITDB_PARSE_COMPOSER
};


enum {
	SECTION_TRACK = MHSD_TYPE_TRACK,
	SECTION_PLAYLIST = MHSD_TYPE_PLAYLIST
};



#endif
