#define ERROR_MESSAGE 1;

void error_window(char *message);
void close_message();

struct message
{
	int enabled;
	char *message;
	int type;
	int left, top, width, height, text_top;
	} messages;
