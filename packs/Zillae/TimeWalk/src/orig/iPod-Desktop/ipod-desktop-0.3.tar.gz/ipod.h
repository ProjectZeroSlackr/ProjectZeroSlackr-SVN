int ipod_ioctl(int request, int *arg);
