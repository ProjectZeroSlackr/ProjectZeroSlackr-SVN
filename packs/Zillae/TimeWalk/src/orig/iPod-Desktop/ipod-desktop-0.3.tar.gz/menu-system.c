#define MWINCLUDECOLORS
#include "nano-X.h"
#include "menu-logic.h"
#include "graphics.h"
#include "messages.h"
#include "menu-system.h"
#include "ipod.h"
#include <fcntl.h>
#ifdef IPOD
#include <linux/fb.h>
#endif
#include <sys/ioctl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define FBIOSET_BACKLIGHT _IOW('F', 0x25, int)

void execute_system(int system_id)
{
	static int backlight;
	switch (system_id)
	{
		case SYSTEM_REBOOT:
			system("reboot");
			GrClose();
			exit(0);
			break;
		case SYSTEM_QUIT:
			GrClose();
			exit(0);
			break;
		case SYSTEM_BACKLIGHT:
			if (backlight==0)
			{
				backlight=1;
				}
			else
			{
				backlight=0;
				}
			//ipod_ioctl(FBIOSET_BACKLIGHT, &backlight);
		}
	}
