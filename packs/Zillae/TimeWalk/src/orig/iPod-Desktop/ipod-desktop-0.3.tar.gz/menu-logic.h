#define MENU_TYPE_FILE 1
#define MENU_TYPE_MENU 2
#define MENU_TYPE_SYSTEM 3
#define MENU_NORMAL_USE -1;

union menu_location {
	char *file;
	struct menu_system *menu;
	int system;
	};

struct menu_eintrag {
	char *name;
	int image;
	int image_selected;
	int type;
	union menu_location location;
	};

extern struct menu_system {
	struct menu_system *parent;
	char *name;
	int count;
	int position;
	int scrolling;
	struct menu_eintrag *eintrag;
	} *menu;


void set_menu_logic();
void move_up();
void move_down();
void execute_menu();
int load_menus(char *file, struct menu_system** menu);
void close_menu();
