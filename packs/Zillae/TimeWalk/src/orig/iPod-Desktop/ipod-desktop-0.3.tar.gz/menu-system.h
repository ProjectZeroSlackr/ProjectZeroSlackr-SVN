#define SYSTEM_REBOOT 1
#define SYSTEM_QUIT 2
#define SYSTEM_BACKLIGHT 3

void execute_system(int system_id);
