#include "ipod.h"

#define FB_DEV_NAME		"/dev/fb0"
#define FB_DEVFS_NAME		"/dev/fb/0"

int ipod_ioctl(int request, int *arg)
{
#ifdef IPODd
	int fd;

	fd = open(FB_DEV_NAME, O_NONBLOCK);
	if (fd < 0) fd = open(FB_DEVFS_NAME, O_NONBLOCK);
	if (fd < 0) {
		return -1;
		}
	if (ioctl(fd, request, arg) < 0) {
		close(fd);
		return -1;
		}
	close(fd);

	return 0;
#else
	return -1;
#endif
	}
