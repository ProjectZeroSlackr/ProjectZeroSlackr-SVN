#include "menu-logic.h"
#include "graphics.h"
#include "memory.h"
#include "menu-system.h"
#include <stdio.h>
//#include <string.h>
#define MOVE_SPACE 2

struct menu_system *menu;
char menus[]= "abcdefg";

void menu_load_befehl(char *befehl, char *wert, FILE *file, struct menu_system *menu);
struct menu_system *add_menu_eintrag(struct menu_system *menu, char *name, int type, void *value, int image, int image_selected);
void load_menu(FILE *file, struct menu_system *menu);
int read_anzahl_eintrage(FILE *file);


void set_menu_logic()
{
	}

int move=2;

void move_up()
{
	if (move==0)
	{
		move=MOVE_SPACE;
		if (menu->position > 0)
		{
			menu->position--;
			if (menu->position == menu->scrolling && menu->position!=0)
			{
				menu->scrolling--;
				paint_menus();
				}
			else
			{
				paint_menu_zeile(menu->position+1, (menu->position+1-menu->scrolling)* ZEILEN_HOEHE);
				paint_menu_zeile(menu->position, (menu->position-menu->scrolling)* ZEILEN_HOEHE);
				paint_scroll_bar();
				}
			}
		}
	else
	{
		move--;
		}
	}

void move_down()
{
	if (move==MOVE_SPACE)
	{
		move=0;
		if (menu->position < menu->count-1)
		{
			menu->position++;
			if (menu->position == menu->scrolling + MAX_ZEILEN-1 && menu->position!=menu->count-1)
			{
				menu->scrolling++;
				paint_menus();
				}
			else
			{
				paint_menu_zeile(menu->position-1, (menu->position-1-menu->scrolling)* ZEILEN_HOEHE);
				paint_menu_zeile(menu->position, (menu->position-menu->scrolling)* ZEILEN_HOEHE);
				paint_scroll_bar();
				}
			}
		}
	else
	{
		move++;
		}
	}

void execute_menu()
{
	char *message;
	switch (menu->eintrag[menu->position].type)
	{
		case MENU_TYPE_FILE:
			message=get_mem(sizeof(char)*(strlen(menu->eintrag[menu->position].location.file)+10));
			strcpy(message, "Starte:\n");
			strcat(message, menu->eintrag[menu->position].name);
			error_message(message);
			system(menu->eintrag[menu->position].location.file);
			close_message();
			GrMapWindow (wid);
			GrGetFocus();
			break;
		case MENU_TYPE_MENU:
			menu=menu->eintrag[menu->position].location.menu;
			set_header_space();
			paint_menus();
			break;
		case MENU_TYPE_SYSTEM:
			execute_system(menu->eintrag[menu->position].location.system);
		}
	}

void close_menu()
{
	if (menu->parent!= 0)
	{
		menu=menu->parent;
		set_header_space();
		paint_menus();
		}
	}


int load_menus(char *file, struct menu_system **menu)
{
	FILE *fp;
	int i=0;
	if (fp= fopen(file, "r"))
	{
		*menu= get_menu_system(i=read_anzahl_eintrage(fp), "ipod-desktop", 0);
		load_menu(fp, *menu);
		set_header_space();
		printf("fertig\n");
		return 1;
		}
	else
	{
		return 0;
		}
	}

void menu_load_befehl(char *befehl, char *wert, FILE *fp, struct menu_system *menu)
{
	static char name[256];
	static char file[256];
	static int image, image_selected;
	if (strcmp(befehl, "file")==0)//neue verkn�pfung
	{
		strcpy(name, wert);
		}
	else if (strcmp(befehl, "location")==0)//ziel der verkn�pfung
	{
		strcpy(file, wert);
		}
	else if (strcmp(befehl, "end-file")==0)//verkn�pfung sdhreiben
	{
		add_menu_eintrag(menu, name, MENU_TYPE_FILE, file, image, image_selected);
		image= 0;
		image_selected= 0;
		}
	else if (strcmp(befehl, "menu")==0)//neues untermen�
	{
		load_menu(fp, add_menu_eintrag(menu, wert, MENU_TYPE_MENU, fp, image, image_selected));
		image= 0;
		image_selected= 0;
		}
	else if (strcmp(befehl, "system")==0)//neuer systemeintrag
	{
		strcpy(name, wert);
		}
	else if (strcmp(befehl, "end-system")==0)//system eintrag schreiben
	{
		add_menu_eintrag(menu, name, MENU_TYPE_SYSTEM, file, image, image_selected);
		image= 0;
		image_selected= 0;
		}
	else if (strcmp(befehl, "image")==0)//bild hinzuf�gen
	{
		image=GrLoadImageFromFile(wert, 0);
		}
	else if (strcmp(befehl, "image:selected")==0)//bild:selected hinzuf�gen
	{
		image_selected=GrLoadImageFromFile(wert, 0);
		}
	*befehl= '\0';
	*wert= '\0';
	}

struct menu_system
*add_menu_eintrag(struct menu_system *menu, char *name, int type, void *value, int image, int image_selected)
{
	struct menu_eintrag *menu_eintrag;
	menu_eintrag= menu->eintrag;
	menu_eintrag+=menu->count++;
	menu_eintrag->name= (char *) get_mem(sizeof(char)*(strlen(name)+1));
	strcpy(menu_eintrag->name, name);
	menu_eintrag->location.file= 0;
	menu_eintrag->image= image;
	menu_eintrag->image_selected= image_selected;
	switch (type)
	{
		case MENU_TYPE_FILE:
			menu_eintrag->type= MENU_TYPE_FILE;
			menu_eintrag->location.file= get_mem(sizeof(char)*(strlen((char *) value)+1));
			strcpy(menu_eintrag->location.file, (char *) value);
			break;
		case MENU_TYPE_SYSTEM:
			menu_eintrag->type= MENU_TYPE_SYSTEM;
			menu_eintrag->location.system= atoi((char *) value);
			break;
		case MENU_TYPE_MENU:
			menu_eintrag->type=MENU_TYPE_MENU;
			menu_eintrag->location.menu= get_menu_system(read_anzahl_eintrage((FILE *) value), name, menu);
			return menu_eintrag->location.menu;
			break;
		}
	}

void load_menu(FILE *file, struct menu_system *menu)
	{
	int i=0;
	int mode=1;
	char befehl[64];
	char wert[256];
	int c='a';
	*befehl= '\0';
	*wert= '\0';
	while (((c=getc(file))!=EOF) && (strcmp(befehl, "end-menu")))
	{
		switch (mode) //befehl oder wert einlesen
		{
			case 1:  //steuerungsbefehl einlesen
				switch (c)
				{
					case '=':
						mode= 2;
						break;
					case '\n':
					case '\0':
						menu_load_befehl(befehl, wert, file, menu);
						break;
					case ' ':
					case '\t':
						break;
					default:
						strncat(befehl, (char *) &c, 1);
					}
				break;
			case 2:  //wert einlesen
				if ((c == '\n') || (c == '\0'))
				{
					mode= 1;
					menu_load_befehl(befehl, wert, file, menu);
					}
				else
				{
					strncat(wert, (char *) &c, 1);
					}
			}
		}
	}

int read_anzahl_eintrage(FILE *file)
{
	int menus=1;
	int anzahl=0;
	long position;
	signed char c;
	char wert[64];
	*wert= '\0';
	position=ftell(file);
	while (((c=getc(file))!=EOF) && (menus>0))
	{
		switch (c)
		{
			case ' ':
			case '\t':
				break;
			case '=':
				while ((c=getc(file)!='\n') && (c!=EOF));
			case '\n':
				if (menus==1)
				{
					if (strcmp(wert, "file")==0)
					{
						anzahl++;
						}
					else if (strcmp(wert, "system")==0)
					{
						anzahl++;
						}
					else if (strcmp(wert, "menu")==0)
					{
						anzahl++;
						menus++;
						}
					}
				if (strcmp(wert, "end-menu")==0)
				{
					menus--;
					}
				*wert= '\0';
				break;
			default:
				strncat(wert, &c, 1);
			}
		}
	fseek(file, position, SEEK_SET);
	return anzahl;
	}
