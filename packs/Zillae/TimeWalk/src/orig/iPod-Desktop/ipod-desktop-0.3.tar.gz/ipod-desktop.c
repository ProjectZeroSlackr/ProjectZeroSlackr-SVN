#define MWINCLUDECOLORS
#include "nano-X.h"
#include "menu-logic.h"
#include "graphics.h"
#include "messages.h"
#include <stdio.h>


void event_handler (GR_EVENT *event);


int main (void)
{
	if (GrOpen() < 0)
	{
	fprintf (stderr, "GrOpen failed");
	exit (1);
	}

	gc = GrNewGC();
	GrSetGCUseBackground (gc, GR_FALSE);
	GrSetGCForeground (gc, WHITE);
	GrGetScreenInfo(&screen_info);

	wid = GrNewWindowEx (GR_WM_PROPS_APPFRAME |
			GR_WM_PROPS_CAPTION  |
			GR_WM_PROPS_CLOSEBOX,
			"ipod-desktop",
			GR_ROOT_WINDOW_ID,
			0, 0, screen_info.cols, screen_info.rows, BLACK);

	GrSelectEvents (wid, GR_EVENT_MASK_EXPOSURE |
			GR_EVENT_MASK_CLOSE_REQ |
			GR_EVENT_MASK_KEY_DOWN);

	GrMapWindow (wid);
	set_fonts();
	set_menu_logic();
	error_message("Lade Einstellungen ");
	if (!load_menus("/etc/ipod-desktop.conf", &menu))
	{
		close_message();
		error_message("Konnte Einstellungen nicht laden! ");
		menu= get_menu_system(0, "ipod-desktop");
		}
	else {
		close_message();
		}
	GrMainLoop (event_handler);
}

void event_handler (GR_EVENT *event)
{
	switch (event->type)
	{
	case GR_EVENT_TYPE_KEY_DOWN:
		if (messages.enabled==1)
		{
			close_message();
			}
		else
		{
			switch (event->keystroke.ch)
			{
				case 'm':
					close_menu();
					break;
				case 'r':
					move_down();
					break;
				case 'l':
					move_up();
					break;
				case '\r':
					execute_menu();
				}
			}
		GrSetGCForeground (gc, BLACK);
		break;

	case GR_EVENT_TYPE_EXPOSURE:
		paint_menus();
		if (messages.enabled==1)
		{
			paint_message();
			}
		break;

	case GR_EVENT_TYPE_CLOSE_REQ:
		GrClose();
		exit (0);
		break;
	}
}
