
#ifndef __STEROIDS_GRAFIX_H__
#define __STEROIDS_GRAFIX_H__

#define MWINCLUDECOLORS
#include <nano-X.h>


#define PI 3.141592653589793
#define PI2 6.283185307179586


void PutRect(int x, int y, int w, int h, int r, int g, int b);



#endif
