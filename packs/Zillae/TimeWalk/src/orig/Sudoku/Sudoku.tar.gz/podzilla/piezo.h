
#ifndef __PIEZO_H__
#define __PIEZO_H__

void toggle_piezo(void);
void beep(void);

#endif
